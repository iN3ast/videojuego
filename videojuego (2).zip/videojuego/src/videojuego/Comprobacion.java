package videojuego;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Comprobacion {
	
	    Scanner teclado = new Scanner(System.in);

	    private String Introducido;
	    private int dni;
	    private char letIntro;
	    
	    boolean correcto=false;
	    boolean numero=false;
	 
	   public boolean validarDNI(String validar) { 
			  
	  boolean salida = false ; 
	 
        Comprobacion Dni = new Comprobacion();
        
        Dni.setDniIntroducido(validar);
      
       
        Dni.getLetraIntroducida();
      
        String []numeros=validar.split("");
        
		   for(int i=0;i<numeros.length-1;i++)
			   
		   {
			 
			   if(!Character.isDigit(validar.charAt(i))) {
				   
				   numero=true;
				   correcto=true;
				   System.out.println("Formato Incorrecto");
							    
			   } 
				  
		    }
        	
        	if (validar.length() == 9 && correcto == false) {
        		
        	      Dni.setDniNumero(Dni.getDniIntroducido());
        	        
	        	  if(Dni.getLetIntro() != Dni.CalcularLetra()) {
	                  System.out.println("La letra introducida en el Dni no coincide con la verdadera letra");
	                
	              }
	              else {
	              	
	              	System.out.println("El dni " + Dni.getDniIntroducido() + " es un Dni v�lido");
	              	salida=true;
	              	}
	              
	        	  
	        } else { System.out.println("DNI incorrecto, no tiene 9 digitos");}
	      
        	
	       return salida ; 
	        
	    }
  
	    char CalcularLetra() {
	        int resto;
	        resto = dni % 23;
	        char letra = 0;
	        
	        switch(resto) {
	            case 0:
	                letra = 'T';
	                break;
	            case 1:
	                letra = 'R';
	                break;
	            case 2:
	                letra = 'W';
	                break;
	            case 3:
	                letra = 'A';
	                break;
	            case 4:
	                letra = 'G';
	                break;
	            case 5:
	                letra = 'M';
	                break;
	            case 6:
	                letra = 'Y';
	                break;
	            case 7:
	                letra = 'F';
	                break;
	            case 8:
	                letra = 'P';
	                break;
	            case 9:
	                letra = 'D';
	                break;
	            case 10:
	                letra = 'X';
	                break;
	            case 11:
	                letra = 'B';
	                break;
	            case 12:
	                letra = 'N';
	                break;
	            case 13:
	                letra = 'J';
	                break;
	            case 14:
	                letra = 'Z';
	                break;
	            case 15:
	                letra = 'S';
	                break;
	            case 16:
	                letra = 'Q';
	                break;
	            case 17:
	                letra = 'V';
	                break;
	            case 18:
	                letra = 'H';
	                break;
	            case 19:
	                letra = 'L';
	                break;
	            case 20:
	                letra = 'C';
	                break;
	            case 21:
	                letra = 'K';
	                break;
	            case 22:
	                letra = 'E';
	                break;
	        }
	        return letra;
	    }
		 public void getLetraIntroducida(){
			
			letIntro = Character.toUpperCase(Introducido.charAt(Introducido.length()-1)); 
			
		  }
	    
	    public void setDniIntroducido(String dniIntroducido) {
	        this.Introducido = dniIntroducido;
	    }
	    
	    public  void setDniNumero(String dni) {
			   
			   if(numero==false) {
				
				   this.dni = Integer.parseInt(Introducido.substring(0, Introducido.length()-1));
			   } else System.out.println("Formato incorrecto");
			  
		   }
		       
	    
	    public String getDniIntroducido() {
	        return Introducido;
	    }
	    
	    char getLetIntro() {
	        return letIntro;
	    }
	   
	}
	
