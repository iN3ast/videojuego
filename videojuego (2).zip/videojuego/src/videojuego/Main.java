package videojuego;
import java.util.Scanner;

public class Main {

		/*Gestor gestor = new Gestor();
		
		
		gestor.menu(); */
		
		public static void main(String[] args) {
			
			Scanner teclado = new Scanner(System.in);
			
			//CREACI�N ARRAYS AUXILIARES
			
			Gestor gestor = new Gestor();
			
			gestor.menu();
		/*	
			Habilidad habilidades[] = new Habilidad[55];
			Item items[] = new Item[60];
			Personaje personajes[] = new Personaje[55];
			Zona zonas[] = new Zona[55];
			Mision misiones[] = new Mision[55];
			
			//HABILIDADES
			for(int i=0; i<55;i++)
				habilidades[i] = new Habilidad("Habilidad"+ i,i+1,i+1,"tipo" + 1);
			
			
			

			
			Habilidad auxhabilidad[] = new Habilidad[5];
			auxhabilidad[0] = habilidades[0];
			auxhabilidad[1] = habilidades[1];
			auxhabilidad[2] = habilidades[2];
			
			//ITEM
			for(int i=0;i<20;i++)
				items[i] = new Armadura("Armadura " + i, i, auxhabilidad, i, i);
			for(int i=20;i<40;i++)
				items[i] = new Consumible("Consumible " + i, i, auxhabilidad, i);
			for(int i=40;i<60;i++)
				items[i] = new Arma("Arma " + i, i, auxhabilidad, i, i);
			Item auxitems []  = new Item[5];
			auxitems[0] = items[0];
			auxitems[1] = items[20];
			auxitems[2] = items[40];
			
			
		
			
			//Personaje
			for(int i=0;i<55;i++)
			{
				personajes[i] = new Personaje("nombre "+i, "clase "+i, 200,200,200,200,0,auxhabilidad,auxitems, false, false );
			}
			
			Personaje[] auxpersonajes = new Personaje[55];
			auxpersonajes[0] = personajes[0];
			auxpersonajes[1] = personajes[1];
			auxpersonajes[2] = personajes[2];
			

			teclado.nextLine();
			Gestor gestor = new Gestor();
			System.out.println("Comprobar Habilidades vacias");
			gestor.mostrarHabilidades();
			teclado.nextLine();
			
			System.out.println("Comprobar Personajes vacios");
			gestor.mostrarPersonajes();
			teclado.nextLine();
			
			
			gestor.guardarEnFichero();
			System.out.println("Comprobar ficheros vacio");
			teclado.nextLine();
			
			for(int i =0;i<5; i++)
			{
				gestor.anyadirHabilidad(habilidades[i]);
			}
			gestor.anyadirItem(items[0]);
			gestor.anyadirItem(items[20]);
			gestor.anyadirItem(items[40]);
			for(int i =0;i<5; i++)
			{
				gestor.anyadirPersonaje(personajes[i]);
			}
			
			
			gestor.leerDeFichero();
				System.out.println("Comprobar Habilidades vacias");
			gestor.mostrarHabilidades();
			teclado.nextLine();
			
			System.out.println("Comprobar Personajes vacios");
			gestor.mostrarPersonajes();
			teclado.nextLine();
			gestor.guardarEnFichero();
			System.out.println("Comprobar ficheros vacios despues de crear y leer vacio");
			teclado.nextLine();
			
			for(int i =0;i<5; i++)
			{
				gestor.anyadirHabilidad(habilidades[i]);
			}
			gestor.anyadirItem(items[0]);
			gestor.anyadirItem(items[20]);
			gestor.anyadirItem(items[40]);
			for(int i =0;i<5; i++)
			{
				gestor.anyadirPersonaje(personajes[i]);
			}
			
		
			gestor.guardarEnFichero();
			System.out.println("Comprobar ficheros con datos");
			teclado.nextLine();
			
			for(int i =0;i<10; i++)
			{
				gestor.anyadirHabilidad(habilidades[i]);
			}
			gestor.anyadirItem(items[0]);
			gestor.anyadirItem(items[20]);
			gestor.anyadirItem(items[40]);
			for(int i =0;i<10; i++)
			{
				gestor.anyadirPersonaje(personajes[i]);
			}
			System.out.println("deben haber 10 habilidades y 10 personajes");
			teclado.nextLine();
			System.out.println("10 Hab");
			teclado.nextLine();
			
			gestor.mostrarHabilidades();
			teclado.nextLine();
			
			System.out.println("10 perso");
			teclado.nextLine();
			
			gestor.mostrarPersonajes();
			teclado.nextLine();
			
			System.out.println("leemos para limpiary quedaran 5 ");
			teclado.nextLine();
			System.out.println("5 Hab");
			teclado.nextLine();
			gestor.leerDeFichero();
			gestor.mostrarHabilidades();
			
			teclado.nextLine();
			
			System.out.println("5 perso");
			teclado.nextLine();
			
			gestor.mostrarPersonajes();
			teclado.nextLine();
			*/
			
		}
		}
		



	

