package videojuego;

public class Mision {

	// DECLARAMOS LAS VARIABLES
	
	private String nombre ; 
	private int nivel ; 
	private Personaje objetivo ; 
	private Zona zona ; 
	private Item recompensa ; 
	private int monedas ; 
	private int numItem;
	private int numZona;
	private int numPer;
	
	public Mision() { // METODO CONSTRCUTOR POR DEFECTO
		
		nombre ="NINGUNO";
		nivel = 0 ; 
		objetivo = new Personaje(); 
		zona = new Zona();
		recompensa = new Consumible();
		monedas = 0 ; 
		numItem= 0 ;
		numPer=0 ;
		numZona=0 ;
		 
	}
	
	public Mision (String nombre , int nivel , Personaje objetivo ,Zona zona,Item recompensa , int monedas) {
		
		// METODO SOBRECARGADO
		
		this.numItem= 0 ;
		this.numPer = 0 ;
		this.numZona=0;
		
		this.nombre =nombre;
		this.nivel = nivel ; 	
		this.objetivo = objetivo;
		this.numPer++;	
		this.recompensa = recompensa;
		this.numItem++;
			 	
		this.zona = zona;
		this.numZona++;
		this.monedas = monedas ; 
		
	}
	public Mision (Mision mision){
		
		this.nombre = mision.nombre;
		this.nivel = mision.nivel ; 
		this.objetivo = mision.objetivo ; 
		this.zona = mision.zona ;
		this.recompensa = mision.recompensa;
		this.monedas = mision.monedas ; 
		
	}
	
	public void visualizar () { // VISUALIZAMOS NUESTROS DATOS 
		System.out.println("------------------------MISION-------------------------");
		System.out.println("Nombre: "+ nombre);
		System.out.println("Nivel : "+ nivel);
		System.out.println("Numero de Personaje : "+ numPer);
		System.out.println("Numero de Zona : "+ numZona);
		System.out.println("Numero de Item : "+ numItem);

	
		System.out.println("Monedas : "+ monedas);
		System.out.println("_________________________________________________________");
		System.out.println();
	}
	
	public void  visualizarBasico() {
		
		System.out.println("------------------------MISION-------------------------");
		System.out.println("Nombre: "+ nombre);
		System.out.println("Nivel : "+ nivel);
		System.out.println("Numero de Personaje : "+ numPer);
		System.out.println("Numero de Zona : "+ numZona);
		System.out.println("Numero de Item : "+ numItem);

	
		System.out.println("Monedas : "+ monedas);
		System.out.println("_________________________________________________________");
		System.out.println();
		
		
	}
	boolean esIgual(Mision mision) { 
        boolean salida=false;
        
        if(this.nombre.equals(mision.nombre) &&
            this.nivel==mision.nivel &&
            this.objetivo.esIgual(mision.objetivo))
        	salida=true;
          
        return salida;

    }

	public int getNumItem() {
		return numItem;
	}

	public void setNumItem(int numItem) {
		this.numItem = numItem;
	}

	public int getNumZona() {
		return numZona;
	}

	public void setNumZona(int numZona) {
		this.numZona = numZona;
	}

	public int getNumPer() {
		return numPer;
	}

	public void setNumPer(int numPer) {
		this.numPer = numPer;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public Personaje getObjetivo() {
		return objetivo;
	}

	public void setObjetivo(Personaje objetivo) {
		this.objetivo = objetivo;
	}

	public Zona getZona() {
		return zona;
	}

	public void setZona(Zona zona) {
		this.zona = zona;
	}

	public Item getRecompensa() {
		return recompensa;
	}

	public void setRecompensa(Item recompensa) {
		this.recompensa = recompensa;
	}

	public int getMonedas() {
		return monedas;
	}

	public void setMonedas(int monedas) {
		this.monedas = monedas;
	}
	
}
