package videojuego;


public class Habilidad {
	
	// DECLARAMOS LAS VARIABLES 
	private String nombre ; 
	private int vida ; 
	private int energia ; 
	private String tipo ; 
	
	public Habilidad () { // METODO CONSTRCUTOR POR DEFECTO DE LA CLASE
		
		nombre = " NINGUNO";
		vida = 0 ;  
		energia = 0 ; 
		tipo = " TIPO";
	}
	
	public Habilidad (String nombre, int vida,int energia, String tipo) { //  METODO SOBRECARGADO
	
		this.nombre = nombre;
		this.vida = vida ;  
		this.energia = energia ; 
		this.tipo = tipo;
		
	}
	public Habilidad (Habilidad habilidad) { // METODO DE COPIA
	
		this.nombre = habilidad.nombre;
		this.vida = habilidad.vida ;  
		this.energia = habilidad.energia ; 
		this.tipo = habilidad.tipo;
		
		}
	
	public void visualizar () { // VISUALIZAMOS NUESTROS ATRIBUTOS DE LA CLASE
		
			System.out.println("-------------HABILIDAD-------------");
			System.out.println("Nombre: "+ nombre);
			System.out.println("Vida: "+ vida);
			System.out.println("Energia : "+ energia);
			System.out.println("Tipo : "+ tipo); 
			
			System.out.println();
		
	}
	
	public void visualizarBasico() {
		
		System.out.println("-------------HABILIDAD-------------");
		System.out.println("Nombre: "+ nombre);
		System.out.println("Vida: : "+ vida);
		System.out.println("Energia : "+ energia);
		System.out.println("Tipo : "+ tipo); 
		
		System.out.println();
		
	}
	public boolean esIgual(Habilidad habilidad) {
			
			boolean salida = false;
			if(this.nombre.equals(habilidad.nombre))
				salida = true;
			return salida;
		}
	
	
	@Override
	public boolean equals(Object objeto) {
		
		boolean salida = false ; 
		
		Habilidad habilidad = (Habilidad) objeto;
	   
		if(this.nombre.equals(habilidad.nombre))
			salida = true;
		
		
		return salida;
		
	}
	
	public String toString()
    {
        String salida;
        salida =  nombre+";"+vida+ ";"+energia+";"+tipo+"\n" ;
        return salida;
    }
	
	// GETTES Y SETTES

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getEnergia() {
		return energia;
	}

	public void setEnergia(int energia) {
		this.energia = energia;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}	
	
	
}
	
	
	