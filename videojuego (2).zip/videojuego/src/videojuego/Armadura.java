package videojuego;

public class Armadura extends Item {
	
	private int armadura ; 
	private int peso;
	
	
	
	Armadura (){
		
		super();
		armadura = 0 ; 
		peso = 0 ; 
	
	}
	
	Armadura (Armadura Armadura)  {
		
		this.armadura = Armadura.armadura ;
		this.peso = Armadura.peso ; 
		
		for (int i= 0 ; i < this.acciones.length ; i++) {
			
			if(acciones [i]!=null && !this.tiene(acciones[i])) {
				
			this.acciones [i] = Armadura.acciones[i]; 
			
			}
		}
	}

	Armadura (String nombre,int valor,Habilidad [] acciones , int armadura, int peso){
		
		this.nombre = nombre ; 
		this.armadura = armadura ; 
		this.peso = peso ; 
		
		this.acciones= new Habilidad [5];
		for (int i= 0 ; i < this.acciones.length; i++) {
			
			if(acciones [i]!=null && !this.tiene(acciones[i])) {

				this.acciones [numhabiItem] = acciones [i] ; 
				this.numhabiItem ++ ; 
			}
	
			
		}
		
	}
	
public void visualizar(){
		
		System.out.println(" ---ARMADURA----");
		System.out.println("Nombre : " + nombre);
		System.out.println("Valor : "+ valor);
		System.out.println("Numero de habilidades : "+ numhabiItem );
		System.out.println("Agravio : "+ armadura);
		System.out.println("Peso :"+ peso);
		System.out.println();
	}

	public void visualizarBasico() {
		
		System.out.println(" ---ARMADURA----");
		System.out.println("Nombre : " + nombre);
		System.out.println("Valor : "+ valor);
		System.out.println("Numero de habilidades : "+ numhabiItem );
		System.out.println("Agravio : "+ armadura);
		System.out.println("Peso :"+ peso);
		System.out.println();
		
		
	}


	public int getArmadura() {
		return armadura;
	}

	public void setArmadura(int armadura) {
		this.armadura = armadura;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}
}
