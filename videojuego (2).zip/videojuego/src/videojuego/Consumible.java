package videojuego;

public class Consumible extends Item {
	
	protected int cantidad ; 
	
	
	Consumible () {
		
		super();
		cantidad = 0 ; 
	}
	
	Consumible (Consumible consumible) {
		
		this.cantidad = consumible.cantidad ; 
		
		
		for (int i= 0 ; i < this.acciones.length ; i++) {
			
			if(acciones [i]!=null && !this.tiene(acciones[i])) {
				
			this.acciones [i] = consumible.acciones[i]; 
			
			}
		}
	}
	
	
	Consumible (String nombre,int valor , Habilidad [] acciones, int cantidad ){
		
		this.nombre = nombre ; 
		this.cantidad = cantidad ; 
		this.valor = valor ; 
		
		this.acciones= new Habilidad [5];
		for (int i= 0 ; i < this.acciones.length; i++) {
			
			if(acciones [i]!=null && !this.tiene(acciones[i])) {

				this.acciones [numhabiItem] = acciones [i] ; 
				this.numhabiItem ++ ; 
			}
	
		
		
	}
}
	
   public void visualizar(){
		
		System.out.println(" ---CONSUMIBLE----");
		System.out.println("Nombre : " + nombre);
		System.out.println("Valor : "+ valor);
		System.out.println("Numero de habilidades : "+ numhabiItem );
		System.out.println("Cantidad : "+ cantidad);
		System.out.println();
		
	}
   
   public void visualizarBasico() {
	   
	   System.out.println(" ---CONSUMIBLE----");
		System.out.println("Nombre : " + nombre);
		System.out.println("Valor : "+ valor);
		System.out.println("Numero de habilidades : "+ numhabiItem );
		System.out.println("Cantidad : "+ cantidad);
		System.out.println();
   }


	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	
	
}
