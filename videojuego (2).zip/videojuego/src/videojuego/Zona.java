package videojuego;

public class Zona {
	
	private String nombre ;
	private int nivel;
	private Personaje npc [];
	private int numPer;
	
	public Zona () {
		numPer=0;
		npc = new Personaje [5];
		nombre = "NINGUNO";
		nivel = 0 ; 
		
		for (int i = 0 ; i < npc.length; i++) 
		{
			npc [i] = new Personaje ();
		
		}
	}

	public Zona (String nombre,int nivel,Personaje npc []){
		this.numPer=0;
		this.nombre = nombre;
		this.nivel = nivel ;
		this.npc = new Personaje [5];
		for (int i = 0 ; i < npc.length; i++) 
		{
			 if(npc [i]!=null ) {
			this.npc [numPer] = npc[i];
			 this.numPer++;
			 }
		}
	
	}
	public Zona (Zona zona) {
		
		this.nombre = zona.nombre;
		this.nivel = zona.nivel ;
		
		for (int i = 0 ; i < npc.length; i++) 
		{
			 if(npc [i]!=null ) {
			this.npc [i] = zona.npc[i];
			
			
			 }
		}
	}
	public void visualizar() {
		
		System.out.println("----------------ZONAS------------------");
		System.out.println("Nombre : "+ nombre);
		System.out.println("Nivel : "+ nivel);
		System.out.println("Numero de Personajes : "+ numPer);
		System.out.println("_______________________________________");
		System.out.println();
		
	}
	
	public void visualizarBasico() {
		
		System.out.println("----------------ZONAS------------------");
		System.out.println("Nombre : "+ nombre);
		System.out.println("Nivel : "+ nivel);
		System.out.println("Numero de Personajes : "+ numPer);
		System.out.println("_______________________________________");
		System.out.println();
		
	}


	public void visualizarPerZona() {
		
	
		for (int i = 0 ; i < this.npc.length; i++) 
		{
			 if(this.npc [i]!=null ) { 
				 
				System.out.println();
				System.out.println("Personaje: " + (i+1));
				 npc[i].visualizar();	
			 }
		}
		
		
	}
	
	boolean esIgual(Zona zona) {
		
        boolean salida=false;
        if(this.nombre.equals(zona.nombre))
           
        	salida=true;
        return salida;

    }
	
	public int getNumPer() {
		return numPer;
	}

	public void setNumPer(int numPer) {
		this.numPer = numPer;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public Personaje[] getNpc() {
		return npc;
	}

	public void setNpc(Personaje[] npc) {
		this.npc = npc;
	}
}
