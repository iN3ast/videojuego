package videojuego;

public class Personaje {

	private String nombre ; 
	private String clase ;
	private int vida_max ; 
	private int energia_max ;
	private int vida_actual ;
	private int energia_actual;
	private int monedas ;
	private Habilidad habilidad[] ;
	private Item equipo [];
	private boolean npc ; 
	private boolean hostil ;
	
	int numitem;
	int numhabi; 

	public Personaje () {
		numitem= 0 ; 
		numhabi = 0 ; 
		habilidad = new Habilidad [5];
		equipo = new Item[10];
		
		nombre = "NINGUNO"; 
		clase = "NINGUNO";
		vida_max = 0; 
		vida_actual=0;
		energia_actual = 0;
		energia_max= 0 ;
		monedas = 0 ;
		
		npc = true ; 
		hostil= true ;
			
	}
	
	public Personaje (String nombre , String clase ,int vida_max , int energia_max, int vida_actual, int energia_actual,int monedas ,Habilidad habilidad[] ,Item equipo [],boolean npc,boolean hostil ){
		this.numhabi = 0 ; 
		this.numitem = 0 ;
		
		this.vida_actual =vida_actual;
		this.energia_actual =energia_actual;
		this.nombre= nombre ; 
		this.clase= clase ;
		this.vida_max= vida_max ; 
		this.energia_max = energia_max ;
		this.monedas = monedas ;
		this.habilidad = new Habilidad [5];
		this.equipo = new Item [10];
		for (int i = 0 ; i < habilidad.length;i++) {
			
			 if(habilidad [i]!=null ) {
				 
				 this.habilidad[numhabi]= habilidad[i];
				 this.numhabi++;
			 }
		}
		 for (int i = 0 ; i < equipo.length;i++) {
			
			 if(equipo [i]!=null ) {
				 
				 this.equipo [numitem]= equipo[i];
				 this.numitem++;
			 }
			
		 }
		 
		this.npc= npc ; 
		this.hostil= hostil ;
		
	}
	
	public Personaje (Personaje personaje){ 
	
		this.nombre= personaje.nombre ; 
		this.clase= personaje.clase ;
		this.vida_max= personaje.vida_max ; 
		this.energia_max = personaje.energia_max ;
		this.monedas = personaje.monedas ;
		
		 for (int i = 0 ; i < habilidad.length;i++) {
			 this.habilidad[i]= personaje.habilidad[i];
			 this.equipo [i]= personaje.equipo[i];
		 }
		this.npc= personaje.npc ; 
		this.hostil= personaje.hostil ;	
	}
	
	public void visualizar () {
		
		System.out.println("--------------PERSONAJE---------------");
		System.out.println("Nombre : "+ nombre);
		System.out.println("Clase : "+ clase);
		System.out.println("Vida_max : "+ vida_max);
		System.out.println("Energia_max : "+ energia_max);
		System.out.println("Monedas : "+ monedas);
		System.out.println("Vida actual : " + vida_actual);
		System.out.println("Energia maxima : "+ energia_actual);
		System.out.println("Npc : "+ npc);
		System.out.println("Hostil : "+ hostil);
		System.out.println("Numero de Habilidades : "+ numhabi);
		System.out.println("Numero de Items : "+ numitem);
		System.out.println("_______________________________________");
		System.out.println();
		
		
		
	}
	
	public void visualizarBasico() {
		
		System.out.println("--------------PERSONAJE---------------");
		System.out.println("Nombre : "+ nombre);
		System.out.println("Clase : "+ clase);
		System.out.println("Vida_max : "+ vida_max);
		System.out.println("Energia_max : "+ energia_max);
		System.out.println("Monedas : "+ monedas);
		System.out.println("Vida actual :" + vida_actual);
		System.out.println("Energia maxima : "+ energia_actual);
		System.out.println("Npc : "+ npc);
		System.out.println("Hostil : "+ hostil);
		System.out.println("Numero de Habilidades : "+ numhabi);
		System.out.println("Numero de Items : "+ numitem);
		System.out.println("_______________________________________");
		System.out.println();
		
		
	}
	
	public void visualizarHabPer () {
	
		for (int i = 0 ; i <this.habilidad.length; i++) {
				
			if (this.habilidad[i]!= null) { 
				
			System.out.println();
			System.out.println("Habilidad: " + (i+1));
			habilidad[i].visualizar();	
			
			}
		 } 
		
		
	} 
		
	public void visualizarItemPer () {
		
		
		 for (int i = 0 ; i <this.equipo.length; i++) {
				
				if (this.equipo[i]!= null) { 
					
				System.out.println();
				System.out.println("Equipo: " + (i+1));
				equipo[i].visualizar();		
			}
		 } 
		
	
	}
	
	public boolean esIgual(Personaje personaje) {
		
		 boolean salida = false ; 
		
		if (this.nombre.equals(personaje.nombre))
			salida= true ;
		
		return salida ; 
	}
	
	@Override
	public boolean equals(Object objeto) {
		
		boolean salida = false ; 
		
		Personaje personaje = (Personaje) objeto;
	   
		if(this.nombre.equals(personaje.nombre))
			salida = true;
		
		
		return salida;
		
	}

	public String toString()
    {
        String salida;
        salida =  nombre+";"+clase+";"+vida_max+";"+energia_max+";"+vida_actual+";"+energia_actual+";"+monedas+";"+npc+";"+hostil+";" ;
        
        for( int i = 0 ; i < this.habilidad.length; i++) {
        	
        	if(this.habilidad[i] != null) {
        		
        		if (i  != numhabi-1)
        		salida += habilidad[i].getNombre().toString()+",";
        			
        		else salida += habilidad[i].getNombre().toString();
        				
        	}   		
        
        }
        
        return salida;
    }
	
	public int getVida_actual() {
		return vida_actual;
	}

	public void setVida_actual(int vida_actual) {
		this.vida_actual = vida_actual;
	}

	public int getEnergia_actual() {
		return energia_actual;
	}

	public void setEnergia_actual(int energia_actual) {
		this.energia_actual = energia_actual;
	}

	public int getNumitem() {
		return numitem;
	}

	public void setNumitem(int numitem) {
		this.numitem = numitem;
	}

	public int getNumhabi() {
		return numhabi;
	}

	public void setNumhabi(int numhabi) {
		this.numhabi = numhabi;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getClase() {
		return clase;
	}

	public void setClase(String clase) {
		this.clase = clase;
	}

	public int getVida_max() {
		return vida_max;
	}

	public void setVida_max(int vida_max) {
		this.vida_max = vida_max;
	}

	public int getEnergia_max() {
		return energia_max;
	}

	public void setEnergia_max(int energia_max) {
		this.energia_max = energia_max;
	}

	public int getMonedas() {
		return monedas;
	}

	public void setMonedas(int monedas) {
		this.monedas = monedas;
	}

	public Habilidad[] getHabilidad() {
		return habilidad;
	}

	public void setHabilidad(Habilidad[] habilidad) {
		this.habilidad = habilidad;
	}

	public Item[] getEquipo() {
		return equipo;
	}

	public void setEquipo(Item[] equipo) {
		
		this.equipo = equipo;
	}

	public boolean isNpc() {
		return npc;
	}

	public void setNpc(boolean npc) {
		this.npc = npc;
	}

	public boolean isHostil() {
		return hostil;
	}

	public void setHostil(boolean hostil) {
		this.hostil = hostil;
	}
	
	
}
