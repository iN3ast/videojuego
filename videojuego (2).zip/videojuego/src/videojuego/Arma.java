package videojuego;

public class Arma extends Item {
	
	
	protected int agravio ; 
	protected int peso ; 
	
	
	Arma () {
		
		super();
		agravio = 0 ; 
		peso = 0 ; 
	}
	
	Arma (Arma arma ){
		
		this.agravio = arma.agravio ; 
		this.peso = arma.peso ; 
		
		
		for (int i= 0 ; i < this.acciones.length ; i++) {
			
			if(acciones [i]!=null && !this.tiene(acciones[i])) {
				
			this.acciones [i] = arma.acciones[i]; 
			
			}
		}
		
		
	}
	
	Arma (String nombre, int valor, Habilidad [] acciones, int agravio,int peso) {
		
		
		this.nombre = nombre ; 
		this.valor = valor ;
		this.agravio = agravio;
		this.peso = peso ; 
		
		this.acciones= new Habilidad [5];
		for (int i= 0 ; i < this.acciones.length; i++) {
			
			if(acciones [i]!=null && !this.tiene(acciones[i])) {

				this.acciones [numhabiItem] = acciones [i] ; 
				this.numhabiItem ++ ; 
			}
	
		
		
	}
		
		
		
	}
	
	public void visualizar(){
		
		System.out.println(" ---ARMA----");
		System.out.println("Nombre : " + nombre);
		System.out.println("Valor : "+ valor);
		System.out.println("Numero de habilidades : "+ numhabiItem );
		System.out.println("Agravio : "+ agravio);
		System.out.println("Peso :"+ peso);
		System.out.println();
	}

	public int getAgravio() {
		return agravio;
	}

	public void setAgravio(int agravio) {
		this.agravio = agravio;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

}
