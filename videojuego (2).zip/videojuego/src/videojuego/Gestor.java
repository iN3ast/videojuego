package videojuego;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

import java.util.Scanner;

import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Gestor {
	
	private Scanner teclado = new Scanner(System.in);
	
	// DECLARAMOS LAS VARIABLES PRIVADAS
	
	public ArrayList<Item> items;
	public Zona [] zonas;
	public Mision [] misiones;
	public ArrayList<Habilidad> habilidades;
	public ArrayList <Personaje> personajes ; 
	public Usuario [] users ;
	private int numhab;
	private int numitem; 
	private int numZona ; 
	private int numMis;
	private int numPers;
	
	String basedatos = "videojuego_java";
    String host = "localhost";
    String port = "3306";
    String parAdic = "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    String urlConnection = "jdbc:mysql://" + host + ":" + port + "/" + basedatos + parAdic;
    String user = "iN3ast";
    String pwd = "Madrid1967";
	
	public Gestor() // GENERAMOS EL METODO CONSTRUCTOR POR DEFECTO DE NUESTRO GESTOR
	{
	
		habilidades = new ArrayList<Habilidad>();
	
		personajes = new ArrayList <Personaje>();
		items = new ArrayList<Item>();
		
		zonas = new Zona [50];
		misiones = new Mision [50];
		users= new Usuario[50];
		
		leerDeFichero();
		
		numhab=0;
		numitem=0;	
		numZona= 0;
		numMis= 0 ; 
		numPers = 0 ; 
		
		
	}
	
	public void leerDeFichero() {
		
		FileReader file ;
		FileReader file2 ;
		
		items.clear();
		personajes.clear();
		habilidades.clear();
	
		
		for(int i = 0 ; i< 50;i++) {
			
			misiones[i] = null;
			zonas[i] = null ; 
			
		}
		
		try (
			       Connection c = DriverManager.getConnection(urlConnection, user, pwd);
			        Statement s = c.createStatement();
			        ResultSet rs = s.executeQuery("SELECT * FROM habilidad")) {
			
			 
			  while (rs.next()) {
				  
				  String nombre = rs.getString("nombre");
				  int vida = Integer.parseInt(rs.getString("vida"));
			      int energia =  Integer.parseInt(rs.getString("energia"));
			      String tipo = rs.getString("tipo");
			      
			      Habilidad auxiliar = new Habilidad(nombre,vida,energia,tipo);
				     
			        anyadirHabilidad(auxiliar);
			  
			  }
			
			}
		/*
			file2 = new FileReader("C:\\DAM\\personajes.txt");
			BufferedReader personaje = new BufferedReader(file2);
			
			file = new FileReader("C:\\DAM\\habilidades.txt");
			BufferedReader habilidad = new BufferedReader(file);
		
			
			 while((cadena = habilidad.readLine())!=null) {
				 
				  aux = cadena.split(";");
				 
				if (aux.length>1 && aux !=null) {
					
					String nombre = aux[0];
					int vida = Integer.parseInt(aux[1]);
			        int energia =  Integer.parseInt(aux[2]);
			        String tipo = aux[3];
			        
			        Habilidad auxiliar = new Habilidad(nombre,vida,energia,tipo);
			     
			        anyadirHabilidad(auxiliar);
					
					
				}
			     
		      }
			 System.out.println();
			
			 while((cadena = personaje.readLine())!=null) {
				 
				 aux = cadena.split(";");
				 
				 if (aux.length>1 && aux !=null) {
						
						String nombre = aux[0];
						String clase = aux[1] ;
				        int vida_max =  Integer.parseInt(aux[2]);
				        int energia_max =  Integer.parseInt(aux[3]);
				        int vida_actual =  Integer.parseInt(aux[4]);
				        int energia_actual = Integer.parseInt(aux[5]);
				        int monedas =  Integer.parseInt(aux[6]);
				        
				        boolean npc = Boolean.parseBoolean(aux[7]);
				        boolean hostil = Boolean.parseBoolean(aux[8]); 
				        
				        Item [] auxItem = new Item [5];
				        Habilidad [] auxHabilidad = new Habilidad [5];
				        
				    	Personaje auxiliar = new Personaje(nombre,clase,vida_max,energia_max,vida_actual,energia_actual, monedas,auxHabilidad,auxItem,npc,hostil); // CREAMOS UN PERSONAJE 
				        
				    	anyadirPersonaje(auxiliar);
				    	
				        if (aux.length > 9) {
				        	
				        	 String [] aux1 = aux[9].split(",");
						        
					    	for(int i = 0 ; i <aux1.length ; i++) {
					        	
					        	Habilidad habilidad1 = new Habilidad(aux1[i],0,0,"");
					        	
					        	int pos = habilidades.indexOf(habilidad1);
					        	
					        	if(pos !=-1) 
					        		
					        		modHabPer(auxiliar,habilidad1,true);		        		
					        }
		    				
				        }      	
				  }
				       
		       }
			 
			 System.out.println();
			 
			personaje.close();
			file2.close();
			
			habilidad.close();
			file.close();
			*/
		catch (Exception e) {
		      e.printStackTrace(System.err);
		    }
		try (
			       Connection c = DriverManager.getConnection(urlConnection, user, pwd);
			        Statement s = c.createStatement();
			        ResultSet rs = s.executeQuery("SELECT * FROM personaje")) {
			
			 
			  while (rs.next()) {
				  
				String nombre = rs.getString("nombre");
				String clase = rs.getString("clase") ;
		        int vida_max =  Integer.parseInt(rs.getString("vida_max"));
		        int energia_max =  Integer.parseInt(rs.getString("energia_max"));
		        int vida_actual =  Integer.parseInt(rs.getString("vida_actual"));
		        int energia_actual = Integer.parseInt(rs.getString("energia_actual"));
		        int monedas =  Integer.parseInt(rs.getString("monedas"));
		        
		        boolean npc = Boolean.parseBoolean(rs.getString("npc"));
		        boolean hostil = Boolean.parseBoolean(rs.getString("hostil")); 
		        
		        Item [] auxItem = new Item [5];
		        Habilidad [] auxHabilidad = new Habilidad [5];
		        
		    	Personaje auxiliar = new Personaje(nombre,clase,vida_max,energia_max,vida_actual,energia_actual, monedas,auxHabilidad,auxItem,npc,hostil); // CREAMOS UN PERSONAJE 
		        
		    	anyadirPersonaje(auxiliar);
			  
			  }
			
			} catch (Exception e) {
			      e.printStackTrace(System.err);
			    }
		
	}
	
	public void guardarEnFichero() {
			
		FileWriter file;
		FileWriter file2;
	
		
		try {
		
			file = new FileWriter("C:\\DAM\\habilidades.txt",false);
			BufferedWriter habilidad = new BufferedWriter(file);
			for(int i = 0 ; i < habilidades.size();i++) {
				
				habilidad.write(habilidades.get(i).toString());
			}
	
			
			file2 = new FileWriter("C:\\DAM\\personajes.txt",false);
			BufferedWriter personaje = new BufferedWriter(file2);
			
			for(int i = 0 ; i < personajes.size() ;i++) {
				
				personaje.write(personajes.get(i).toString()+"\n");
			}

			habilidad.close();
			file.close();
			
			personaje.close();
			file2.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		   int hostil, npc ; 
		   String nombrePj="";
           String clasePj="";
           int vida_Max=0;
           int vida_Actual=0;
           int energia_Max=0;
           int energia_Actual=0;
           int monedas=0;
       
		
		    try (
		    		
		            Connection c = DriverManager.getConnection(urlConnection, user, pwd);
		            Statement s = c.createStatement()) {

		    
		    	
		    	if (personajes.size() > 0 ) {
		    		
		    		for (int i = 0 ; i < personajes.size();i++) {
			    		
		    			nombrePj=personajes.get(i).getNombre();
		            	clasePj=personajes.get(i).getClase();
		            	vida_Max=personajes.get(i).getVida_max();
		            	vida_Actual=personajes.get(i).getVida_actual();
		            	energia_Max=personajes.get(i).getEnergia_max();
		            	energia_Actual=personajes.get(i).getEnergia_actual();
		            	monedas=personajes.get(i).getMonedas();
		            	
		            	Habilidad []habaux=new Habilidad[5];
		            	Item []itemaux=new Item[5];
		            	Personaje aux=new Personaje(nombrePj,clasePj,vida_Max,energia_Max,vida_Actual,energia_Actual,monedas,habaux,itemaux,personajes.get(i).isHostil(),personajes.get(i).isNpc());
		            	
		    				if (personajes.get(i).isNpc() == true ) npc = 1; 
			    			else npc = 0 ; 
			    			
			    			if ( personajes.get(i).isHostil() == true) hostil = 1 ; 
			    			else hostil = 0 ; 
			    		
			    			  if((personajes.get(i).esIgual(aux))) {
			    		
			     		   int nFil = s.executeUpdate("INSERT INTO personaje (nombre,clase,vida_max,vida_actual,energia_max,energia_actual,monedas,npc,hostil) VALUES "
			  		              + "('" + nombrePj +"','"+ clasePj +"','"+ vida_Max +"','" 
			     				  + vida_Actual +"','" + energia_Max+"','"+ energia_Actual+"','"
			  		              + monedas +"','" + npc+"','"+ hostil+"')");
			 		    	}
		    		}
			 		      System.out.println(" Filas insertadas.");
		    				
		    			
		    		
		    		
		 		     
		    	} else System.out.println("No hay mas personajes para meter en la base de datos");
		    	
		    	 String nombre="";
		          int vida =0;
		          int energia =0;
		          String tipo = "";
		          
		    	if (habilidades.size() > 0 ) {
		    		
		    		for (int i = 0 ; i < habilidades.size();i++) {
			    		
		    			 nombre = habilidades.get(i).getNombre();
			        	 vida = habilidades.get(i).getVida();
			        	 energia = habilidades.get(i).getEnergia();
			        	 tipo = habilidades.get(i).getTipo();
			        	  Habilidad aux= new Habilidad(nombre,vida,energia,tipo);
		    	
			        	  if((habilidades.get(i).esIgual(aux))) {
		     		   int nFil = s.executeUpdate("INSERT INTO habilidad (nombre,vida,energia,tipo) VALUES "
		  		              + "('" + nombre +"','"+ vida +"','"+ energia +"','"
		     				  + tipo +"')");
			        	  }
		 		    	}
		 		   
		 		      System.out.println(" Filas insertadas.");
		 		      
		    	}else System.out.println("No hay mas habilidades para meter en la base de datos");
		    	
		    } 
		    catch (Exception e) {
		      e.printStackTrace(System.err);
		    }
		    
	}
	
	public void menu() // MENU PRINCPIPAL DE NUESTRO PROGRAMA
	{
		int opcion;
		System.out.println("Bienvenido al gestor del videojuego: PRACTICA TERCER TRIMESTRE");
		do {
			System.out.println();
			System.out.println("SELECCIONA LA OPCION A REALIZAR");
			System.out.println();
			System.out.println("Opcion 1: Añadir habilidad");
			System.out.println("Opcion 2: Mostrar habilidades");
			System.out.println("Opcion 3: Eliminar habilidades");
			System.out.println("Opcion 4: Añadir item");
			System.out.println("Opcion 5: Añadir habilidades al item");
			System.out.println("Opcion 6: Eliminar habilidades al item");
			System.out.println("Opcion 7: Mostrar items");	
			System.out.println("Opcion 8: Eliminar items");
			System.out.println("Opcion 9: Añadir Zona");
			System.out.println("Opcion 10: Mostrar Zona");
			System.out.println("Opcion 11: Añadir personaje a la zona");
			System.out.println("Opcion 12: Eliminar personaje a la zona");
			System.out.println("Opcion 13: Eliminar Zona");
			System.out.println("Opcion 14: Añadir Personaje");
			System.out.println("Opcion 15: Mostrar Personaje");
			System.out.println("Opcion 16: Modificamos los items del Personaje");
			System.out.println("Opcion 17: Modificamos las habilidades del Personaje");	
			System.out.println("Opcion 18: Eliminar Personaje");
			System.out.println("Opcion 19: Añadir Mision");
			System.out.println("Opcion 20: Mostrar Mision");
			System.out.println("Opcion 21: Eliminar Mision");
			System.out.println("Opcion 22: Leer Fichero");
			System.out.println("Opcion 23: Guardar Fichero");
			
			System.out.println("Opcion 0: Salir");
			opcion= teclado.nextInt();
			teclado.nextLine();
			
			switch (opcion)
			{
				case 1:
					anyadirHabilidad(); // AÑADIMOS UNA HABILIDAD 
					break;
					
				case 2:
					mostrarHabilidades(); // MOSTRAMOS LAS HABILIDADES 
					break;
				case 3:
					eliminarHabilidad (); // ELIMINAMOS LAS HABILIDADES 
					break;
				case 4:
					anyadirItem();  // AÑADIMOS ITEM 
					break;
				case 5 : 
					asigHabItem(); // AÑADIR HABILIDADES AL ITEM
					break;
				case 6: 
					eliminarHabItem(); // ELIMINAR HABILIDADES AL ITEM	
					break;
				case 7:
					mostrarItems(); // MOSTRAMOS LOS ITEMS 
					break;
					case 8: 
					eliminarItem(); // ELIMINAR LOS ITEMS
					break;
						case 9:
					anyadirZona();  // AÑADIMOS ZONA
					break;
					
				case 10:
					mostrarZonas(); // MOSTRAMOS LAS ZONAS
					break;
					
				case 11 : 
					addPersonajeAZona(); // AÑADIR PERSONAJE A LA ZONA
					break;
				case 12 :
					eliminarPersonajeAZona(); // ELIMINAR PERSONAJE A LA ZONA
					break;
					
				case 13 : 
					eliminarZona(); // ELIMMINAMOS LAS ZONAS
					break;
				case 14: 
					anyadirPersonaje();  // AÑADIMOS PERSONAJE
					break;
				case 15: 
					mostrarPersonajes(); // MOSTRAMOS LOS PERSONAJES
					break;	
				
				case 16 : 
					modEquipo (); // MODIFICAMOS LOS ITEMS DEL PERSONAJE
					break; 
					
				case 17:
					modHabPer(); // MODIFICAMOS LAS HABILIDADES DEL PERSONAJE
				break;
				
				case 18: 
					eliminarPersonaje(); // ELIMINAR LOS PERSONAJES
						break;
				case 19:
					anyadirMision();  // AÑADIMOS MISION 
					break;
	
				case 20 :
					mostrarMisiones(); // MOSTRAMOS LAS MISIONES 
					break;
				case 21:
					eliminarMision(); // ELIMINAR LAS MISIONES
					break;
				case 22:
					
					leerDeFichero();
					
					break;
				case 23: 
					
					guardarEnFichero();
					break;
				case 0:
					System.out.println("Saliendo...");
					break;
					
				default:
					System.out.println("No es una opción admitida");
					break;
			}
		}while(opcion!=0);
	}
	
	// PRINCIPIO DE LOS METODOS DE HABILIDAD ------------------------------------------------------------------------------------------------
	public boolean anyadirHabilidad() // METODO DE AÑADIR HABILIDAD
		{
			boolean salida=false;
		
			System.out.println("Introduce del nombre de la habilidad");
			String nombre = teclado.nextLine();
			System.out.println("Introduce la vida de la habilidad");
			int vida = teclado.nextInt();
			teclado.nextLine();
			System.out.println("Introduce la energia de la habilidad");
			int energia = teclado.nextInt();
			teclado.nextLine();
			System.out.println("Introduce el tipo de la habilidad");
			String tipo = teclado.nextLine();
			
			Habilidad aux = new Habilidad(nombre, vida, energia, tipo); // CREAMOS UNA HABILIDAD CON LOS DATOS RECOGIDOS POR CONSOLA
			
			salida = anyadirHabilidad(aux);  // LLAMAMOS A NUESTRO ANYADIR PASANDO EL OBJETO CREADO
			
			return salida;
		}
	
	public boolean anyadirHabilidad(Habilidad habilidad)
	{
			boolean encontrado = false;
			boolean salida = false; 
			
			if (habilidades !=null) {
				
				for(int i=0;i< habilidades.size();i++) // RECORREMOS NUESTRO ARRAY PARA VER SI LA PALABRA METIDA POR CONSOLA ESTA EN NUESTRO ARRAY
				{
					
						
						if(habilidades.get(i)!=null && habilidades.get(i).esIgual(habilidad)) // SI CUMPLE ESTA CONDICION, ES PORQUE LA PALABRA SE ENCUENTRA EN EL ARRAY
						{
							encontrado =true; 
							i= habilidades.size();
						}
						
				}
				
				if(!encontrado && habilidad !=null) // SINO LO ENCUENTRA EN NUESTRO ARRAY, GUARDAMOS NUESTRA HABILIDAD EN EL ARRAY DE HABILIDADES
				{
					
						habilidades.add(habilidad);
						numhab++;
						salida=true; 
					
				}
				else // SI ENCUENTRA LA PALABRA, MOSTRAMOS POR PANTALLA QUE LA HABILIDAD YA EXISTE
				{
					System.out.println("ERROR ESTA HABILIDAD YA EXISTE");
				}
				
				
			}else System.out.println("");
				
			
			
			
			
			return salida;
		}
		
	public boolean eliminarHabilidad () // METODO DE ELIMINAR HABILIDAD
	{
	
			boolean salida = false ; 
			
			if (numhab > 0){
				
				mostrarHabilidades();
				System.out.println();
				
			
				System.out.println("Introduce la habilidad a eliminar"); // PEDIMOS LA HABILIDAD A ELIMINAR POR CONSOLA
				String nombrehab = teclado.nextLine();
				
				Habilidad aux = new Habilidad(nombrehab,0,0,"");
	
				int posHab= habilidades.indexOf(aux);
			
				if (posHab != -1) {
					
					if ( habilidades.get(posHab) != null  && posHab <= numhab ) {
						
						salida= eliminarHabilidad(habilidades.get(posHab)); // LLAMAMOS A NUESTRO ELIMINAR PASANDO EL OBJETO CREADO		
						
					} else System.out.println("ESA POSICION NO SE ASOCIA A NINGUNA HABILIDAD (NULL)");
					
				}else System.out.println("HABILIDAD NO ENCONTRADA EN EL ARRAY GENERAL DE HABILIDADES");
			}
			else System.out.println("NO HAY HABILIDADES PARA ELIMINAR");
			
			
			return salida; 
			
		}
	
	
	public boolean eliminarHabilidad (Habilidad habilidad) // METODO DE ELIMINAR HABILIDAD
	{
			
			boolean encontrado = false; 
			int pos = habilidades.indexOf(habilidad); // BUSCAMOS LA POSICION DE LA HABILIDAD A ELIMINAR
			
			if(pos!=-1)
			{							
				habilidades.remove(habilidad); // LLAMAMOS AL METODO PRIVADO REMOVE, PARA BORRAR HABILIDAD 
				 encontrado=true;	
			}
			else
			{ 
				System.out.println("HABILIDAD NO ENCONTRADA EN NUESTRO ARRAY GENERAL DE HABILIDADES");
				System.out.println();
				}
			
			return encontrado ; 
			
		}
	

		
	public void mostrarHabilidades() // METODO MOSTRAR HABILIDAD
		{
			for(int i =0; i<habilidades.size(); i++)
			{
				if (habilidades.get(i) != null)
					
				habilidades.get(i).visualizarBasico();
			}
		}
	
	
		// FIN DE LOS METODOS DE HABILIDAD -------------------------------------------------------------------------------------------------------
	
		// PRINCIPIO DE LOS METODOS DE ITEM ------------------------------------------------------------------------------------------------------
		
	public boolean anyadirItem() // METODO DE AÑADIR ITEM
		{
			boolean salida = false;
			int peso ; 
			System.out.println("Introduce el nombre del item");
			String nombre = teclado.nextLine();
		
			System.out.println("Introduce el valor del item");
			int valor = teclado.nextInt();
			teclado.nextLine();
			
			
			Habilidad acciones[] = new Habilidad[5]; // CREAMOS ARRAY DE HABILIDAD PARA LOS ITEMS
			int numhabenitem=0; 
			
			String nombrehab;
			do {
				System.out.println("Elige la habilidad  del item");
				
				mostrarHabilidades();
				System.out.println("Introduce el nombre de la habilidad, \"\" para no anyadir ninguna");
				nombrehab = teclado.nextLine();
				if(!nombrehab.equals(""))
				{
					Habilidad aux = new Habilidad(nombrehab,0,0,"");
					int pos = habilidades.indexOf(aux);
					
					if(pos!=-1)
					{
						acciones[numhabenitem]=habilidades.get(pos);
						numhabenitem++;
					} 
					
				}
			}while(!nombrehab.equals("") && numhabenitem <5);
			
		
			
			System.out.println("Introduce el tipo de item que desee");
			System.out.println();
			System.out.println("-----------------------------------------");
			System.out.println("Opcion 1 : Item Consumible");
			System.out.println("Opcion 2 : Item Arma");
			System.out.println("Opcion 3 : Item Armadura");
			
			int opcion = teclado.nextInt();
			teclado.nextLine();
			switch (opcion) {
			
			case 1 :
				
				System.out.println("Introduce la cantidad del item Consumible");
				int cantidad = teclado.nextInt();
				teclado.nextLine();
				
				Consumible  aux = new Consumible(nombre,valor,acciones,cantidad);
				salida=anyadirItem(aux);
				
				break ; 
			
			case 2 :
				System.out.println("Introduce el agravio del item Arma");
				int agravio = teclado.nextInt();
				teclado.nextLine();
				

				System.out.println("Introduce el peso del item Arma" );
				peso = teclado.nextInt();
				teclado.nextLine();
				
				Arma  aux2 = new Arma(nombre,valor,acciones,agravio,peso);
				
				salida=anyadirItem(aux2);
				
				break ; 
			
			case 3 :
				
				System.out.println("Introduce el agravio del item Armadura");
				int armadura = teclado.nextInt();
				teclado.nextLine();
				

				System.out.println("Introduce el peso del item Armadura" );
				peso = teclado.nextInt();
				teclado.nextLine();
				
				Armadura  aux3 = new Armadura(nombre,valor,acciones,armadura,peso);
				
				salida=anyadirItem(aux3);
				break;
			
			
			}
			
			 // LLAMAMOS A NUESTRO ANYADIR PASANDO EL OBJETO CREADO
			
			return salida;
		}
	
	public boolean anyadirItem(Item item) // METODO DE AÑADIR ITEM
	{
		boolean salida = false;
		
		boolean encontrado = false;
		for(int i=0;i< items.size(); i++) // RECORREMOS NUESTRO ARRAY PARA VER SI LA PALABRA METIDA POR CONSOLA ESTA EN NUESTRO ARRAY
		{
			if(items.get(i)!=null && items.get(i).esIgual(item)) // SI CUMPLE ESTA CONDICION, ES PORQUE LA PALABRA SE ENCUENTRA EN EL ARRAY
			{
				encontrado =true;
				i=items.size();
			}
		}
		
		if(!encontrado) // SINO LO ENCUENTRA EN NUESTRO ARRAY, GUARDAMOS NUESTRO ITEM EN EL ARRAY DE ITEMS
		{
			
				items.add(item);
				numitem++;
				salida =true;
			
		}
		else // SI ENCUENTRA LA PALABRA, MOSTRAMOS POR PANTALLA QUE LA HABILIDAD YA EXISTE
		{
			System.out.println("ERROR ESTE ITEM YA EXISTE");
		}
		
		return salida;
	}
	
	public boolean eliminarItem () // METODO DE ELIMINAR ITEM
	{ 	
		boolean salida = false ; 
		
		if (numitem >0) 
		{	
			mostrarItems();
			System.out.println();
			
			System.out.println("Introduce la posicion del Item a eliminar"); // PEDIMOS LA POSICION DEL ITEM A ELIMINAR POR CONSOLA

			int posItem = teclado.nextInt();
			teclado.nextLine();
	
		    if(posItem!=-1)
            {
                if(items.get(posItem)!=null && posItem <= numitem)
                {

                salida=eliminarItem(items.get(posItem)); // LLAMAMOS A NUESTRO ELIMINAR PASANDO EL OBJETO CREADO

                }else System.out.println("ESA POSICION NO SE ASOCIA A NINGUN ITEM (NULL)");
				
            }else System.out.println("ITEM NO ENCONTRAD0 EN EL ARRAY GENERAL DE ITEMS");
          
		} else System.out.println("NO TIENES ITEMS EN TU ARRAY DE ITEMS PARA ELIMINAR");
		
		return salida ; 
			
		}
	
	public boolean eliminarItem (Item item) // METODO DE ELIMINAR ITEM
	{ 
			
			boolean encontrado = false ; 
			
			int pos = items.indexOf(item); // BUSCAMOS LA POSICION DEL ITEM A ELIMINAR
			
			if(pos!=-1)
			{		
				items.remove(pos); 	// LLAMAMOS AL METODO PRIVADO REMOVE, PARA BORRAR ITEM 
				 encontrado=true;	
			}
			
			else{ 
				System.out.println("ITEM NO ENCONTRAD0 EN NUESTRO ARRAY GENERAL DE ITEMS");
				System.out.println();
			}
			
			return encontrado ; 
			
		}
		

	public boolean asigHabItem() {
		
		boolean salida = false ; 
		mostrarItems();
		System.out.println("Selecciona la posicion del item al que quieras añadir la habilidad");
		int posItem = teclado.nextInt();
		teclado.nextLine();
		
			if ( numitem > posItem && posItem !=-1)	
			{

				System.out.println("LISTA DE HABILIDADES DEL ITEM");
				
				if (items.get(posItem)!=null)
					items.get(posItem).visualizarHabItem();
					System.out.println();
					
					System.out.println("LISTA DE PERSONAJES DEL ARRAY GENERAL");
					System.out.println();
					
					mostrarHabilidades();
					System.out.println("Introduce la habilidad que deseas añadir");
					String nombreHabItem = teclado.nextLine();
					
					Habilidad aux = new Habilidad(nombreHabItem,0,0,"");
					int posHab = habilidades.indexOf(aux);
					
					if (posHab !=-1 ) {
							
					
						salida = asigHabItem(habilidades.get(posHab),items.get(posItem));
							
						
					} else System.out.println("LA HABILIDAD INTRODUCIDA NO EXISTE");
			
			}else System.out.println("ITEM NO ENCONTRADO EN EL ARRAY GENERAL DE ITEMS");
		return salida ;
	}
	
	public boolean asigHabItem(Habilidad habilidad, Item item ) {
		
		boolean encontrado = false ; 
		
		String nombreHabItem = habilidad.getNombre();
		int posItem = items.indexOf(item);
		
			if ( numitem > posItem && posItem !=-1)	
			{
				
				Habilidad aux1 = new Habilidad(nombreHabItem,0,0,"");
					int posHab = habilidades.indexOf(aux1);
					
					if (posHab !=-1 ) {
						
						Habilidad [] aux = new Habilidad [5];
						aux = items.get(posItem).getAcciones();
								
						int posHabItem = obtenerPosHabItem(nombreHabItem,aux);
							
						if (posHabItem == -1) {
								
								for (int i = 0 ; i < aux.length;i++) {
									
									if (aux[i] == null) {
									
									aux[i] = habilidades.get(posHab);
									
									int numhabiItem = items.get(posItem).getNumhabiItem();
									
									numhabiItem++;			
									items.get(posItem).setNumhabiItem(numhabiItem);
									encontrado = true ; 
									i=aux.length;
									}
								}
								
								
						}else System.out.println("HABILIDAD ENCONTRADA EN TU ITEM");
								
					} else System.out.println("LA HABILIDAD INTRODUCIDA NO EXISTE");
			
			}else System.out.println("ITEM NO ENCONTRADO EN EL ARRAY GENERAL DE ITEMS");
		return encontrado ;
	}
	
	public boolean eliminarHabItem() {
		
		boolean salida = false ; 
		
		mostrarItems();
		System.out.println("Introduce el item a la que se desea eliminar la habilidad ");
		int posItem = teclado.nextInt();
		teclado.nextLine();
		
		if (posItem != -1 ) {
			
			System.out.println("LISTA DE HABILIDADES DEL ITEM");
			items.get(posItem).visualizarHabItem();
			System.out.println();
			
			System.out.println("Introduce la habilidad que quieres eliminar ");
			String nombreHabItem = teclado.nextLine();
			
			
			Habilidad aux = new Habilidad(nombreHabItem,0,0,"");
			int posHab = habilidades.indexOf(aux);
			
			if (posHab != -1) {
				
					
				salida = eliminarHabItem(habilidades.get(posHab),items.get(posItem));
					
			}else System.out.println("HABILIDAD NO ENCONTRADO EN NUESTRO ARRAY GENERAL DE HABILIDADES");
			
		} 	else System.out.println("ITEM NO ENCONTRADO EN EL ARRAY GENERAL DE ITEMS");
		
		
		return salida;
		
		
	}
	
	public boolean eliminarHabItem(Habilidad habilidad ,Item item) {
		
		boolean encontrado = false ;  
		
		int posItem = items.indexOf(item);
		
		if (posItem!= -1 ) {
			
			Habilidad [] aux = new Habilidad [5];
			aux =  items.get(posItem).getAcciones();
			
			Habilidad aux1 = new Habilidad(habilidad.getNombre(),0,0,"");
			int posHab = habilidades.indexOf(aux1);
			
			if (posHab != -1) {
				int posHabItem = obtenerPosHabItem(habilidad.getNombre(),aux);
		
				if (posHabItem != -1) {
					
					for (int i = 0 ; i <aux.length;i++) {
						
						if (aux[i] != null){
							
							removeHabItem(aux,posHabItem);
							int numHabClas = items.get(i).getNumhabiItem();
							
							numHabClas--;
							items.get(i).setNumhabiItem(numHabClas);
							encontrado = true;
							i=aux.length;
						}
					}
					
				}
				else System.out.println("HABILIDAD NO EXISTENTE EN ESTE ITEM");
				
			}else System.out.println("HABILIDAD NO ENCONTRADA EN NUESTRO ARRAY GENERAL DE HABILIDADES");
			
		} 	else System.out.println("ITEM NO ENCONTRADO EN EL ARRAY GENERAL DE ITEMS");
	
		return encontrado ; 
		
	}


	private void removeHabItem(Habilidad [] habilidad, int posicion) {
	    int i = posicion;
	    for (; i < habilidad.length- 1; i++) { // MOVEMOS UN SITIO A LA DERECHA EN NUESTRO ARRRAY DE PERSONAJE DE LA ZONA PARTIENDO DE LA POSICION A ELIMINAR
	       habilidad[i] = habilidad[i + 1];
	    }
	    habilidad[i] = null;  // IGUALAMOS A NULL NUESTRA PERSONAJE DE LA ZONA PASANDOLE LA POSICION
	   
	}
	private int obtenerPosHabItem(String nombreHabItem,Habilidad [] habilidad) {  // METODO OBTENER POSICION DE HABILIDAD EN ITEM
		
		int salida = -1 ; // SINO NO ENCUENTRA TE DEVUELVE -1
		
		Habilidad auxiliar = new Habilidad (nombreHabItem,0,0,"");
		for (int i = 0 ; i < habilidad.length; i++)
		{
			if (habilidad[i] != null && habilidad[i].esIgual(auxiliar)) // SI SE CUMPLE LA CONDICION, TE DEVUELVE LA POSICION DEL ITEM
				salida = i ; 
		
		}
		return salida ; 
	}
	
	
	public void mostrarItems() //METODO DE MOSTRAR LOS ITEMS
		{
			for(int i =0; i<items.size(); i++)
			{
				if (items.get(i) != null)
				System.out.println("Posicion "+ i);
				items.get(i).visualizarBasico();
			}
		}
	
			// FIN DE LOS METODOS DE ITEM ------------------------------------------------------------------------------------------------------------
		
		
		// PRINCIPIO DE LOS METODOS DE ZONA ------------------------------------------------------------------------------------------------------
		 
	public boolean anyadirZona() { // METODO DE AÑADIR ZONA
				
			boolean salida = false ;
			
			System.out.println("Introduce el nombre de la zona");
			String nombre = teclado.nextLine();
			System.out.println("Introduce el nivel de la zona");
			int nivel = teclado.nextInt();
			teclado.nextLine();
			
			Personaje npcs[] = new Personaje[5];
			int numPerZona= 0 ;  
			
			String nombrePer;
			do {
				System.out.println("Elige el personaje a introducir");
				mostrarPersonajes();
				System.out.println("Introduce el nombre del personaje, \"\" para no anyadir ninguna");
				nombrePer = teclado.nextLine();
				if(!nombrePer.equals(""))
				{
					Habilidad [] auxHabilidad = new Habilidad [5];
					Item [] auxItem = new Item [5];
					
					Personaje personaje = new Personaje(nombrePer,"",0,0,0,0, 0,auxHabilidad,auxItem,true,false); // CREAMOS UN PERSONAJE 
					int pos = personajes.indexOf(personaje);
					if(pos!=-1)
					{
						npcs[numPerZona]=personajes.get(pos);
						numPerZona++;
						
					}
				}		
			}while(!nombrePer.equals("") && numPerZona<5);
			
			Zona aux = new Zona(nombre ,nivel ,npcs); // CREAMOS UNA ZONA CON LOS DATOS RECOGIDOS POR CONSOLA
			
			salida = anyadirZona(aux);  // LLAMAMOS A NUESTRO ANYADIR PASANDO EL OBJETO CREADO
			
				
			return salida;
		}
	
	public boolean anyadirZona(Zona zona) { // METODO DE AÑADIR ZONA
		
		boolean encontrado = false;
		boolean salida = false; 
		
		for(int i=0;i <50 ;i++) // RECORREMOS NUESTRO ARRAY PARA VER SI LA PALABRA METIDA POR CONSOLA ESTA EN NUESTRO ARRAY
		{
			if(zonas[i]!=null && zonas[i].esIgual(zona)) // SI CUMPLE ESTA CONDICION, ES PORQUE LA PALABRA SE ENCUENTRA EN EL ARRAY
			{
				encontrado =true;
				i=50;
			}
		}
		
		if(!encontrado) // SINO LO ENCUENTRA EN NUESTRO ARRAY, GUARDAMOS NUESTRA ZONA EN EL ARRAY DE ZONAS
		{
			if(numZona < 50)
			{
				zonas[numZona]=zona;
				numZona++;
				salida =true;
			}
			else // SI YA TENEMOS 50 ITEMS EN EL ARRAY, MOSTRARÁ QUE ESTA LLENO
			{
				System.out.println("NO HAY MAS CAPACIDAD EN NUESTRO ARRAY GENERAL DE ZONAS");
				System.out.println();
			}
		}
		else  // SI ENCUENTRA LA PALABRA, MOSTRAMOS POR PANTALLA QUE LA ZONA YA EXISTE
		{
			System.out.println("ERROR ESTA ZONA YA EXISTE");
			System.out.println();
		}
		
			
		return salida;
	}
	
	public int addPersonajeAZona() {
		
		int salida = -1 ; 
		
		mostrarZonas();
		System.out.println("Introduce la zona a la que se desea añadir el personaje ");
		String nomZona = teclado.nextLine();
		
		int posZona =obtenerPosZona(nomZona);
		
		
		if (posZona != -1 ) {
			
			System.out.println("LISTA DE PERSONAJES DE LA ZONA");
			zonas[posZona].visualizarPerZona();
			System.out.println();
			
			System.out.println("LISTA DE PERSONAJES DEL ARRAY GENERAL");
			System.out.println();
			
			mostrarPersonajes();
			System.out.println("Introduce el personaje que quieres añadir ");
			String nomNuevoPer = teclado.nextLine();
			
			Habilidad [] auxHabilidad = new Habilidad [5];
			Item [] auxItem = new Item [5];
			
			Personaje personaje = new Personaje(nomNuevoPer,"",0,0,0,0, 0,auxHabilidad,auxItem,true,false); // CREAMOS UN PERSONAJE 
			int posPer = personajes.indexOf(personaje);
			
			if (posPer != -1) {
				
				salida = addPersonajeAZona(personajes.get(posPer),zonas[posZona]);
					
			}else System.out.println("PERSONAJE NO ENCONTRADO EN NUESTRO ARRAY GENERAL DE PERSONAJES");
			
		} 	else System.out.println("ZONA NO ENCONTRADO EN EL ARRAY GENERAL DE ZONAS");
		
		return salida ; 
		
	}
	
	public int addPersonajeAZona(Personaje personaje,Zona zona) {
		
		int salida = -1 ; 
		
		int posZona =obtenerPosZona(zona.getNombre());
		
		if (posZona != -1 ) {
			
			Personaje [] aux = new Personaje [5];
			aux =  zonas[posZona].getNpc();
			
			int posPer =personajes.indexOf(personaje);
			
			if (posPer != -1) {
				int posPerZona = obtenerPosPerZona(personaje.getNombre(),aux);
		
				if (posPerZona == -1) {
					
					for (int i = 0 ; i <aux.length;i++) {
						
						if (aux[i] == null){
							
							aux[i] = personajes.get(posPer);
							int numPerClas = zonas[posZona].getNumPer();
							
							numPerClas++;
							zonas[posZona].setNumPer(numPerClas);
							salida = 1;
							i=aux.length;
						}	
					}
					
				}
				else System.out.println("PERSONAJE YA EXISTENTE EN ESTA ZONA");
				
			}else System.out.println("PERSONAJE NO ENCONTRADO EN NUESTRO ARRAY GENERAL DE PERSONAJES");
			
		} 	else System.out.println("ZONA NO ENCONTRADO EN EL ARRAY GENERAL DE ZONAS");
		
		return salida ; 
		
	}

	public int eliminarPersonajeAZona() {
		
		int salida = -1 ; 
		
		mostrarZonas();
		System.out.println("Introduce la zona a la que se desea eliminar el personaje ");
		String nomZona = teclado.nextLine();
		
		int posZona =obtenerPosZona(nomZona);
		
		if (posZona != -1 ) {
			
			System.out.println("LISTA DE PERSONAJES DE LA ZONA");
			zonas[posZona].visualizarPerZona();
			System.out.println();
			
			System.out.println("Introduce el personaje que quieres eliminar ");
			String nomNuevoPer = teclado.nextLine();
			
			Habilidad [] auxHabilidad = new Habilidad [5];
			Item [] auxItem = new Item [5];

			
			Personaje personaje = new Personaje(nomNuevoPer,"",0,0,0,0, 0,auxHabilidad,auxItem,true,false); // CREAMOS UN PERSONAJE 
			int posPer = personajes.indexOf(personaje);
			
			if (posPer != -1) {
				
				salida = eliminarPersonajeAZona(personajes.get(posPer),zonas[posZona]);
					
			}else System.out.println("PERSONAJE NO ENCONTRADO EN NUESTRO ARRAY GENERAL DE PERSONAJES");
			
		} 	else System.out.println("ZONA NO ENCONTRADO EN EL ARRAY GENERAL DE ZONAS");
		
	
		return salida ; 
		
	}
	
	public int eliminarPersonajeAZona(Personaje personaje ,Zona zona) {
		
		int salida = -1 ; 
		
		int posZona =obtenerPosZona(zona.getNombre());
		
		if (posZona != -1 ) {
			
			Personaje [] aux = new Personaje [5];
			aux =  zonas[posZona].getNpc();
			
			int posPer = personajes.indexOf(personaje);
			
			if (posPer != -1) {
				int posPerZona = obtenerPosPerZona(personaje.getNombre(),aux);
		
				if (posPerZona != -1) {
					
					for (int i = 0 ; i <aux.length;i++) {
						
						if (aux[i] != null){
							
							removePerZona(aux,posPerZona);
							int numPerClas = zonas[posZona].getNumPer();
							
							numPerClas--;
							zonas[posZona].setNumPer(numPerClas);
							salida = 1;
							i=aux.length;
						}
					}
					
				}
				else System.out.println("PERSONAJE NO EXISTENTE EN ESTA ZONA");
				
			}else System.out.println("PERSONAJE NO ENCONTRADO EN NUESTRO ARRAY GENERAL DE PERSONAJES");
			
		} 	else System.out.println("ZONA NO ENCONTRADO EN EL ARRAY GENERAL DE ZONAS");
	
		return salida ; 
		
	}

	private void removePerZona(Personaje[] personaje, int posicion) {
	    int i = posicion;
	    for (; i < personaje.length- 1; i++) { // MOVEMOS UN SITIO A LA DERECHA EN NUESTRO ARRRAY DE PERSONAJE DE LA ZONA PARTIENDO DE LA POSICION A ELIMINAR
	        personaje[i] = personaje[i + 1];
	    }
	    personaje[i] = null;  // IGUALAMOS A NULL NUESTRA PERSONAJE DE LA ZONA PASANDOLE LA POSICION
	   
	}

	private int obtenerPosPerZona(String nomPer,Personaje [] npc){ // METODO PARA OBTENER LA POSICION DEL PERSONAJE DE LA ZONA
       
		int posPerZona= -1; // SINO NO ENCUENTRA TE DEVUELVE -1
       
        Personaje auxiliar = new Personaje();
        Habilidad []aux = new Habilidad [5];
        Item[] auxItem = new Item [5];

        for (int i = 0 ; i< npc.length; i++)
        {
        	if (npc[i]!=null)
        		 auxiliar = new Personaje(nomPer,"",0,0,0,0,0,aux,auxItem, true,false); 
        	
        	if (npc[i] != null && npc[i].esIgual(auxiliar) ) { // SI SE CUMPLE LA CONDICION, TE DEVUELVE LA POSICION DEL PERSONAJE EN ESA ZONA
        		
        		posPerZona = i ;
        	}

        }
       
        return posPerZona;
    }
	
	public boolean eliminarZona (){ // METODO DE ELIMINAR ZONA
		
		boolean salida = false ; 
			
		if (numZona > 0  ){
				
			mostrarZonas();
			System.out.println();
			
			System.out.println("Introduce el nombre de la zona a eliminar"); // PEDIMOS LA ZONA A ELIMINAR POR CONSOLA
			String nombreZona = teclado.nextLine();
		
			int posZona= obtenerPosZona(nombreZona);
			
			if (posZona != -1) {
				
				if ( zonas[posZona] != null  && posZona <= numZona ) {
					
					salida = eliminarZona(zonas[posZona]); // LLAMAMOS A NUESTRO ELIMINAR PASANDO EL OBJETO CREADO
					
					
				} else System.out.println("ESA POSICION NO SE ASOCIA A NINGUNA ZONA (NULL)");
				
			}else System.out.println("ZONA NO ENCONTRADA EN EL ARRAY GENERAL DE ZONAS");
		}
		else System.out.println("NO HAY ZONAS PARA ELIMINAR");

			return salida ; 
			
		}
	
	public boolean eliminarZona (Zona zona){ // METODO DE ELIMINAR ITEM
	
		boolean encontrado = false ;

		int pos = obtenerPosZona(zona.getNombre());
		
		if(pos!=-1)
		{							
			 removeZona(zonas,pos);
			 encontrado=true;	
		
		}
		else
		{ 
			System.out.println("ZONA NO ENCONTRADA EN NUESTRO ARRAY GENERAL DE ZONAS");
			System.out.println();
			}
		
		return encontrado ; 
		
	}
		
	private void removeZona(Zona[] zona, int posicion) {
		     
			int i = posicion;
			
	        for (; i <  numZona- 1; i++) { 	    
	            zona[i] = zona[i + 1]; // MOVEMOS UN SITIO A LA DERECHA EN NUESTRO ARRRAY LAS ZONAS PARTIENDO DE LA POSICION A ELIMINAR
	        }
	        zona[i] = null; // IGUALAMOS A NULL NUESTRA ZONA PASANDOLE LA POSICION
	        numZona--; // RESTAMOS EL CONTADO GENERAL DE ZONAS
    }
		
	private int obtenerPosZona(String nombre) { // METODO PARA OBTENER LA POSICION DE LA ZONA
			
		int salida = -1;
			
		Personaje [] array = new Personaje [5];
		
		Zona aux = new Zona(nombre,0,array);
		
		for(int i = 0; i<numZona; i++)
		{
			if( zonas [i]!= null && zonas[i].esIgual(aux)) // SI SE CUMPLE LA CONDICION, TE DEVUELVE LA POSICION DE LA ZONA
			{
				salida =i;
			}
		}
				
		return salida;
	}
			 
	public void mostrarZonas() // METODO DE MOSTRAR LAS ZONAS
		{
			for(int i =0; i<numZona; i++)	{
				
				if (zonas[i] != null)
				zonas[i].visualizarBasico();
			}
		}
		
		// FIN DE LOS METODOS DE ZONA ------------------------------------------------------------------------------------------------------------
		
		// PRINCIPIO DE LOS METODOS DE PERSONAJES ------------------------------------------------------------------------------------------------
	
		
	public boolean anyadirPersonaje() { // METODO DE AÑADIR PERSONAJE
		// DECLARAMOS NUESTRAS HABILIDADES
		
			Habilidad acciones[] = new Habilidad[5];
			
			String nombrehab;
			boolean salida = false;
			int numhabiPer=0; 
			
			System.out.println("Introduce el nombre del personaje");
			String nombre = teclado.nextLine();
			System.out.println("Introduce la clase del personaje");
			String clase = teclado.nextLine();
			System.out.println("Introduce la vida maxima del personaje");
			int vida_max = teclado.nextInt();
			teclado.nextLine();
			System.out.println("Introduce la energia maxima del personaje");
			int energia_max = teclado.nextInt();
			teclado.nextLine();
			System.out.println("Introduce las monedas del personaje");
			int monedas = teclado.nextInt();
			teclado.nextLine();
			
			System.out.println("Introduce la vida actual del personaje");
			int vida_actual = teclado.nextInt();
			teclado.nextLine();
			System.out.println("Introduce la energia actual del personaje");
			int energia_maxima = teclado.nextInt();
			teclado.nextLine();
					
			System.out.println(" Introduce 0 para que sea ncp o 1 para que no lo sea ");
			int opcion1 = teclado.nextInt();
			boolean npc = false;
			switch (opcion1) {
			
			case 0: 
				 npc = true;
				
				break;
				
			case 1:
				npc = false;
				break;
				default:
					System.out.println("OPCION INCORRECTA, le asignaremos la opcion por defecto");
			}
			
			System.out.println("Introduce un 0 para que sea hostil o 1 para que usuario");
			int opcion2 = teclado.nextInt();
			boolean hostil = false;
			switch (opcion2) {
			
			case 0: 
				 hostil = true;
				
				break;
				
			case 1:
				hostil = false;
				break;
				default:
					
					System.out.println("OPCION INCORRECTA, le asignaremos la opcion por defecto");
			}
	
			teclado.nextLine();
	
			do {
				System.out.println("Elige la habilidad del personaje");
				mostrarHabilidades();
				System.out.println("Introduce el nombre de la habilidad del personaje ,meta un \"\" para no añadir ninguna");
				nombrehab = teclado.nextLine();
				if(!nombrehab.equals(""))
				{
					
					Habilidad aux = new Habilidad(nombrehab,0,0,"");
					int pos = habilidades.indexOf(aux);
					if(pos!=-1)
					{
						acciones[numhabiPer]=habilidades.get(pos);
						numhabiPer++;
					}
				}
				
			}
			while(!nombrehab.equals("") && numhabiPer<10 );
			
			Item item[] = new Item[10];
			
			int numitemPer= 0 ; 
			int pos;
			do {
			System.out.println("Elige el item del personaje");
			mostrarItems();
			      
			System.out.println("Introduce la posicion del item para añadir,meta un -1 para no añadir ninguno");
			pos = teclado.nextInt();
		
				if(pos!=-1)
				{
					if (pos<numitem) {
						
						item[numitemPer]=items.get(pos);
						numitemPer++;
						
					} else System.out.println("NO EXISTE ESA POSICION EN EL ARRAY GENERAL DE ITEMS");
				}
				
			}
		
			while( pos!=-1 && numitemPer<10 );
			
			Personaje aux = new Personaje(nombre,clase,vida_max,energia_max,vida_actual,energia_maxima, monedas,acciones,item,npc,hostil); // CREAMOS UN PERSONAJE 
			
			salida = anyadirPersonaje(aux);  // LLAMAMOS A NUESTRO ANYADIR PASANDO EL OBJETO CREADO
			
			return salida;
		}
	
	public boolean anyadirPersonaje(Personaje personaje) { // METODO DE AÑADIR PERSONAJE
		
		boolean salida = false ; 
		boolean encontrado = false;
		for(int i=0;i<personajes.size();i++) // RECORREMOS NUESTRO ARRAY PARA VER SI LA PALABRA METIDA POR CONSOLA ESTA EN NUESTRO ARRAY
		{
			if(personajes.get(i)!=null && personajes.get(i).esIgual(personaje))
			{
				encontrado =true;
				i=personajes.size();
			}
		}
		
		if(!encontrado) { // SINO LO ENCUENTRA EN NUESTRO ARRAY, GUARDAMOS NUESTRO PERSONAJE EN EL ARRAY DE PERSONAJES
		
			
				personajes.add(personaje);
				numPers++;
				salida =true;
			
		}
		else  // SI ENCUENTRA LA PALABRA, MOSTRAMOS POR PANTALLA QUE LA ZONA YA EXISTE
		{
			System.out.println("ERROR ESTE PERSONAJE YA EXISTE");
			System.out.println();
		}
		
		return salida;
	}
	
	public int modHabPer () {
		
		int salida = -1 ; 
		
		boolean anyadir = true ; 
		
			
			mostrarPersonajes();
			System.out.println("Introduce el personaje que desea modificar");
			String nombrePer = teclado.nextLine();
			System.out.println();
			
			Habilidad [] auxHabilidad = new Habilidad [5];
			Item [] auxItem = new Item [5];
			
			Personaje personaje = new Personaje(nombrePer,"",0,0,0,0, 0,auxHabilidad,auxItem,true,false); // CREAMOS UN PERSONAJE 
			int posPer = personajes.indexOf(personaje);
			
			
			if(posPer < numPers && posPer !=-1)
			{
				System.out.println("LISTA DE HABILIDADES DEL ARRAY GENERAL");
				mostrarHabilidades();
				System.out.println();
				
				System.out.println("LISTA DE HABILIDADES DEL PERSONAJE");
				personajes.get(posPer).visualizarHabPer();
				System.out.println();
				
				System.out.println("Introduce la habilidad que desea ");
				String nomHab = teclado.nextLine();
				
				Habilidad aux = new Habilidad(nomHab,0,0,"");
				int posHab = habilidades.indexOf(aux);
				
				if (posHab !=-1 ) {
					System.out.println("ELIGE LA OPCION A REALIZAR");
					System.out.println();
					System.out.println("Opcion 1: Anaydir habilidad al personaje");
					System.out.println("Opcion 2: Eliminar habilidad al personaje");
					System.out.println("Opcion 0: hacer la accion por defecto");
					int opcion = teclado.nextInt();
					teclado.nextLine();
					
						switch (opcion) {
						
						case 1:
						anyadir = true;
						break;
						case 2:
						anyadir = false ; 
						break;
						default : System.out.println("SE LE ASIGNA EL POR DEFECTO anyadir(TRUE)");
						
						break;
						}
					
					salida = modHabPer(personajes.get(posPer),habilidades.get(posHab),anyadir);
					
				} else System.out.println("HABILIDAD NO ENCONTRADA EN NUESTRO ARRAY GENERAL DE HABILIDADES");
				
			}else System.out.println("PERSONAJE NO ENCONTRADO EN NUESTRO ARRAY GENERAL DE PERSONAJES");
			
		return salida ; 
	}
	
	public int modHabPer (Personaje personaje,Habilidad habilidad, boolean anyadir) {
		
		int encontrado = -1 ; 
		
		int posPer = personajes.indexOf(personaje);
	
		int posHab = habilidades.indexOf(habilidad);
		
		if(posPer!=-1)
		{					
				if (posHab !=-1) {
						if (anyadir == true ) {
							
							encontrado=anyadirHabPer(personaje,habilidad);
						}
						
						if (anyadir == false) {
							
							encontrado= eliminarHabPer(personaje,habilidad);	
					}
				
				} else System.out.println("HABILIDAD NO ENCONTRADA EN EL ARRAY GENERAL DE HABILIDADES");
				
		}
				
		else
		{ 
			System.out.println("PERSONAJE NO VALIDO, INTENTELO DE NUEVO");
			System.out.println();
		}
		
		return encontrado ; 
	}
	
	public int modEquipo (Personaje personaje,Item item, boolean anyadir) {
		
		int encontrado = -1 ; 
		
		int posPer = personajes.indexOf(personaje);
		
		int posItem = items.indexOf(item);
		
		if(posPer!=-1)
		{					
				if (posItem !=-1) {
						
						if (anyadir == true ) {
							
							encontrado=anyadirItemPer(personaje,item);
						}
						
						if (anyadir == false) {
							
							encontrado=eliminarItemPer(personaje,item);
											
					}
				
				} else System.out.println("ITEM NO ENCONTRADO EN EL ARRAY GENERAL DE ITEMS");
				
		}
				
		else
		{ 
			System.out.println("PERSONAJE NO VALIDO, INTENTELO DE NUEVO");
			System.out.println();
		}
		
		return encontrado ; 
	}

	private int anyadirItemPer(Personaje personaje,Item item) {
		
		int salida = -1;
		
		// Recorrer los items del personaje y ver si alguno es igual a los items que tengo		
		// Si no encuentro ningun item añado el item
		int posPer = personajes.indexOf(personaje);
		
		Item  [] aux = new Item [5];
		
		aux = personaje.getEquipo();
		
		int posItem = items.indexOf(item);
		
		int posItemPer = obtenerItemPer(item,personaje.getEquipo());
	
		if (posItemPer == -1 ) {
			
			for (int i = 0 ; i <aux.length;i++) {
				
				if (aux[i] == null){
					
					aux[i] =items.get(posItem);
					int numItemPer = personajes.get(posPer).getNumitem();
				
					numItemPer++;
					personajes.get(posPer).setNumitem(numItemPer);
					salida = 1;
					i=aux.length;
		
				}	
			}
		
		} else System.out.println("");
		
		return salida ;
		
	}

	private int eliminarItemPer(Personaje personaje,Item item) {
		
		int salida = -1;
		
		int posPer = personajes.indexOf(personaje);
		
		Item  [] aux = new Item [5];
		
		aux = personajes.get(posPer).getEquipo();
		
		int posItemPer = obtenerItemPer(item,personaje.getEquipo());
			
		if (posItemPer != -1 ) {
			
			for (int i = 0 ; i <aux.length;i++) {
				
				if (aux[i] != null){
					
					removeItemPer(aux,posItemPer);
					int numItemClas = personajes.get(posPer).getNumitem();
					
					numItemClas--;
					personajes.get(posPer).setNumitem(numItemClas);
					salida = 1;
				
					i=aux.length;
				}
			}
			
			
			
		} else System.out.println("");
		
		return salida ;
		
		
	}

	private int anyadirHabPer(Personaje personaje,Habilidad habilidad) {
		
		int salida = -1;
		
		int posPer = personajes.indexOf(personaje);
		
		Habilidad  [] aux = new Habilidad [5];
		
		aux = personajes.get(posPer).getHabilidad();
		
		int posHab = habilidades.indexOf(habilidad);
		int poshabPer = obtenerHabPer(habilidad.getNombre(),aux);
			
		if (poshabPer == -1 ) {
			
			for (int i = 0 ; i <aux.length;i++) {
				
				if (aux[i] == null){
					
					aux[i] = habilidades.get(posHab);
					int numHabPer = personajes.get(posPer).getNumhabi();
					
					numHabPer++;
					personajes.get(posPer).setNumhabi(numHabPer);
					salida = 1;
					
					i=aux.length;
				}	
			}
		
		
		} else System.out.println("");
		
		return salida ;
		
		
	}
	
	private int eliminarHabPer(Personaje personaje, Habilidad habilidad) {
		
		int salida = -1;
		
		int posPer = personajes.indexOf(personaje);
		
		Habilidad  [] aux = new Habilidad [5];
		
		aux = personajes.get(posPer).getHabilidad();
	
		int poshabPer = obtenerHabPer(habilidad.getNombre(),aux);
			
			if (poshabPer != -1 ) {
				
				for (int i = 0 ; i <aux.length;i++) {
					
					if (aux[i] != null){
						
						removeHabPer(aux,poshabPer);
						int numhabClas = personajes.get(posPer).getNumhabi();
						
						numhabClas--;
						personajes.get(posPer).setNumhabi(numhabClas);
						salida = 1;
					
						i=aux.length;
					}
				}
				
			
		} else System.out.println("ESTA HABILIDAD NO ESTA EN ESTE PERSONAJE");
		
		return salida ;
		
		
	}
	
	public int modEquipo () {
		
		int salida =-1 ; 
		
		boolean anyadir = true ; 
		
		mostrarPersonajes();
		System.out.println("Introduce el personaje que desea modificar");
		String nombrePer = teclado.nextLine();
		System.out.println();
		
		Habilidad [] auxHabilidad = new Habilidad [5];
		Item [] auxItem = new Item [5];
		
		Personaje personaje = new Personaje(nombrePer,"",0,0,0,0, 0,auxHabilidad,auxItem,true,false); // CREAMOS UN PERSONAJE 
		int posPer = personajes.indexOf(personaje);
		if(posPer < numPers && posPer !=-1)
		{
			
			System.out.println("LISTA DE ITEMS DEL ARRAY GENERAL");
			mostrarItems();
			System.out.println();
			
			System.out.println("LISTA DE ITEMS DEL PERSONAJE");
			personajes.get(posPer).visualizarItemPer();
			System.out.println();
			
			System.out.println("Introduce la posicion del item que quieras utilizar ");
			int posItem = teclado.nextInt();
			teclado.nextLine();
			
		
			if (posItem !=-1 ) {
				System.out.println("ELIGE LA OPCION A REALIZAR");
				System.out.println();
				System.out.println("Opcion 1: Anaydir item al personaje");
				System.out.println("Opcion 2: Eliminar item al personaje");
				System.out.println("Opcion 0: Coger la opcion por defecto");
				int opcion = teclado.nextInt();
				teclado.nextLine();
					
					switch (opcion) {
					
					case 1:
					
					anyadir = true;
					break;
					case 2:
					anyadir = false ; 
					break;
					default : System.out.println("SE LE HA ASIGNADO EL POR DEFECTO ANYADIR(TRUE)");
					
					break;
					}

				
				salida = modEquipo(personajes.get(posPer),items.get(posItem),anyadir);
				
			} else System.out.println("HABILIDAD NO ENCONTRADA EN NUESTRO ARRAY GENERAL DE HABILIDADES");
			
		}else System.out.println("PERSONAJE NO ENCONTRADO EN NUESTRO ARRAY GENERAL DE PERSONAJES");
		
		
		return salida ; 
	}

	private void removeHabPer(Habilidad [] habilidad, int posicion) {
        int i = posicion;
        for (; i <  numPers- 1; i++) {
            habilidad[i] = habilidad[i + 1];
        }
        habilidad[i] = null;
      
    }
	
	private void removeItemPer(Item [] item, int posicion) {
        int i = posicion;
        for (; i <  numPers- 1; i++) {
           item[i] = item[i + 1];
        }
        item[i] = null;
      
    }
	
	 	
	private int obtenerItemPer(Item auxiliar,Item [] item){
       
		int positem= -1;
       
      
        for (int i = 0 ; i< item.length; i++)
        {
         	
        	if (item[i] != null && item[i].esIgual(auxiliar) ) {
        		
        		positem = i ;
        	}
        
        }

        return positem; 
	}
	
	private int obtenerHabPer(String nomhab,Habilidad [] habilidad){
        
		int poshab= -1;
       
		Habilidad auxiliar = new Habilidad();

        for (int i = 0 ; i< habilidad.length; i++)
        {
        	if (habilidad[i]!=null)
        		 auxiliar = new Habilidad(nomhab,0,0,""); 
        	
        	if (habilidad[i] != null && habilidad[i].esIgual(auxiliar) ) {
        		
        		poshab = i ;
        	}
        
        }

        return poshab; 
	}
        
	public boolean eliminarPersonaje (){ // METODO DE ELIMINAR PERSONAJE
			
			boolean salida = false ; 
			
			if (numPers > 0){
				
				mostrarPersonajes();
				System.out.println();
				
				System.out.println("Introduce el personaje a eliminar");  // PEDIMOS EL PERSONAJE A ELIMINAR POR CONSOLA
				String nombrePersonaje = teclado.nextLine();
				
				Habilidad [] auxHabilidad = new Habilidad [5];
				Item [] auxItem = new Item [5];
				
				Personaje personaje = new Personaje(nombrePersonaje,"",0,0,0,0, 0,auxHabilidad,auxItem,true,false); // CREAMOS UN PERSONAJE 
				int posPer= personajes.indexOf(personaje);
			
				System.out.println(posPer);
				
				if (posPer != -1) {
					
					if ( personajes.get(posPer) != null  && posPer <= numPers ) {
						
						
						
						salida = eliminarPersonaje(personajes.get(posPer));  // LLAMAMOS A NUESTRO ELIMINAR PASANDO EL OBJETO CREADO
							
					} else System.out.println("ESA POSICION NO SE ASOCIA A NINGUN PERSONAJE (NULL)");
					
				}else System.out.println("PERSONAJE NO ENCONTRAD0 EN EL ARRAY GENERAL DE PERSONAJES");
			}
			else System.out.println("NO HAY PERSONAJES PARA ELIMINAR");
			
			
			return salida ; 
			
		}
	
	public boolean eliminarPersonaje (Personaje personaje){ // METODO DE ELIMINAR PERSONAJE
		
		
		boolean encontrado = false;
		
		int pos = personajes.indexOf(personaje); // BUSCAMOS LA POSICION DEL PERSONAJE A ELIMINAR
		
		if(pos!=-1)
		{							
			 personajes.remove(pos);// LLAMAMOS AL METODO PRIVADO REMOVE, PARA BORRAR HABILIDAD
			 encontrado=true;	
		}
		else
		{ 
			System.out.println("PERSONAJE NO ENCONTRADO EN EL ARRAY");
			System.out.println();
			}
		
		return encontrado ; 
		
	}
	
	
		
	public void mostrarPersonajes() //METODO DE MOSTRAR LOS PERSONAJES
		{
			for(int i =0; i<personajes.size(); i++)
			{
				if (personajes.get(i) != null)
					personajes.get(i).visualizarBasico();
			}
		}
		
		// FIN DE LOS METODOS DE PERSONAJE -------------------------------------------------------------------------------------------------------
		
		// PRINCIPIO DE LOS METODOS DE MISION ----------------------------------------------------------------------------------------------------
	
	public boolean anyadirMision() { // METODO AÑADIR MISION
			 
		// DECLARAMOS NUESTRAS VARIABLES 
		
		String nombreObjMis;
		String nombreZonaMis;
		
		
		Personaje objetivoMis = new Personaje();
		Zona zonaMis = new Zona();
		Item recompensaMis = null;
		
		int numPerMis= 0;
		int numZonaMis= 0;
		int numItemMis = 0;
		
		boolean salida = false ;
		
		System.out.println("Introduce el nombre de la mision");
		String nombre = teclado.nextLine();
		System.out.println("Introduce el nivel de la mision");
		int nivel = teclado.nextInt();
		teclado.nextLine();
			

		do {
		
			mostrarPersonajes();
			System.out.println("Introduce el personaje de la mision");
			nombreObjMis = teclado.nextLine();
			
			Habilidad [] auxHabilidad = new Habilidad [5];
			Item [] auxItem = new Item [5];
			
			Personaje personaje = new Personaje(nombreObjMis,"",0,0,0,0, 0,auxHabilidad,auxItem,true,false); // CREAMOS UN PERSONAJE 
			int pos = personajes.indexOf(personaje);
			if(pos!=-1)
			{
				objetivoMis=personajes.get(pos);
				numPerMis++;
			}
				
		}
		 
		while (!nombreObjMis.equals("") && numPerMis<1); // INTRODUCIMOS UN PERSONAJE A LA MISION,SINO COGE NINGUNO LE COGEMOS EL QUE VENGA EN EL CONSTRUCTOR POR DEFECTO
		
		do {
			
			mostrarZonas();
			System.out.println("Introduce la zona de la mision");
			nombreZonaMis = teclado.nextLine();
			int pos = obtenerPosZona(nombreZonaMis);
			
			if (pos <= numZona)	{
			
				if(pos!=-1)
				{
					zonaMis=zonas[pos];
					numZonaMis++;
				
				} else System.out.println("SE LE HA ASIGNADO LA ZONA POR DEFECTO"); // SI NO PONE LA POSICION SE LE ASIGNA EL ITEM DEL CONSTRUCTOR POR DEFECTO
				
			}else System.out.println("ESA POSICION NO SE ASOCIA A NINGUN ITEM (NULL)");
			
		}
		 
		while (!nombreZonaMis.equals("") && numZonaMis<1);
				
			mostrarItems();
			System.out.println("Introduce la posicion del item para añadir a la mision, -1 para añadir por defecto"); // PEDIMOS LA POSICIONES DEL ITEM 
			int pos=teclado.nextInt();
		if (pos < numitem)	{
			if(pos!=-1) 
			{
				recompensaMis=items.get(pos);
				numItemMis++;
			} else System.out.println("SE LE HA ASIGNADO EL ITEM POR DEFECTO"); // SI LA POSICION ES -1 SE LE ASIGNA EL ITEM DEL CONSTRUCTOR POR DEFECTO
				
		} else System.out.println("ESA POSICION NO SE ASOCIA A NINGUN ITEM (NULL)");
		
	
		System.out.println("Introduce el numero de monedas de la mision");
		int monedas = teclado.nextInt();
		teclado.nextLine();
	
		Mision aux = new Mision(nombre ,nivel,objetivoMis,zonaMis,recompensaMis,monedas); // CREAMOS EL OBJETO CON LOS DATOS PREGUNTADOS POR CONSOLA
		
		salida=anyadirMision(aux); // IGUALAMOS Y LLAMAMOS A NUESTRO AÑADIR, PASANDOLE POR PARAMETRO NUESTRO OBJETO (DEVOLVERA UN BOOLEANO)

			
		return salida;
	}
	
	public boolean anyadirMision(Mision mision) { // METODO AÑADIR MISION
		 
		boolean encontrado = false;
		boolean salida = false ; 
		
		for(int i=0;i< 50;i++)
		{
			if(misiones[i]!=null && misiones[i].esIgual(mision))
			{
				encontrado =true;
				
				i= 50;	
			}
		}
		
		if(!encontrado)
		{
			if(numMis< 50)
			{
				misiones[numMis]=mision;
				numMis++;
				salida =true;
			}
			else
			{
				System.out.println("MISION NO ENCONTRADA EN EL ARRAY GENERAL DE MISIONES");
			}
		}
		else
		{
			System.out.println("ERROR ESTA MISION YA EXISTE");
		}
		
		return salida;
	}
		 
	public boolean eliminarMision (){ // METODO ELIMINAR MISION
		
		boolean salida = false ; 
		
		if (numMis > 0  ){
			
			for (int i = 0 ; i < numMis;i++) { // MOSTRAMOS LOS DATOS DE CADA MISION
				
				System.out.println("Posicion " + i);
				misiones[i].visualizar();
					
			} 

		System.out.println();
		
		System.out.println("Introduce la posicion de la mision a eliminar");
		int posMis = teclado.nextInt();
		
			if ( misiones[posMis] != null  && posMis <= numMis ) { 
				Mision aux = new Mision(misiones[posMis].getNombre(),misiones[posMis].getNivel(),misiones[posMis].getObjetivo(),misiones[posMis].getZona(),misiones[posMis].getRecompensa(),0);
				
				salida = eliminarMision(aux); // LLAMAMOS A NUESTRO ELIMINAR PASANDO EL OBJETO CREADO
				
				
			} else System.out.println("ESA POSICION NO SE ASOCIA A NINGUNA MISION (NULL)");
		
		}
		else System.out.println("NO HAY MISIONES PARA ELIMINAR");
		return salida ; 
				
			}
	
	public boolean eliminarMision (Mision mision){
		
		boolean encontrado = false ; 
		
		int pos = obtenerPosMis(mision.getNombre(),mision.getNivel(),mision.getObjetivo()); // PASAMOS PARAMETROS DE LA MISION, PARA OBTENER SU POSICION
		
		if(pos!=-1)
		{							
			 removeMision(misiones,pos); // LLAMAMOS AL METODO PARA BORRAR NUESTRA MISION, PASANDO EL ARRAY MISIONES Y LA POS DE LA MISION A BORRAR
			 encontrado=true;	
		}
		else
		{ 
			System.out.println("MISION NO ENCONTRADA EN NUESTRO ARRAY GENERAL DE MISIONES");
			System.out.println();
			}
		
		return encontrado ; 
		
	}
	
	private void removeMision(Mision[] mision, int posicion) { 
			        int i = posicion;
			        for (; i <  numMis- 1; i++) { // MOVEMOS UN SITIO A LA DERECHA EN NUESTRO ARRRAY LAS MISONES PARTIENDO DE LA POSICION A ELIMINAR 
			            mision[i] = mision[i + 1];
			        }
			        mision[i] = null; // IGUALAMOS A NULL NUESTRA HABILIDAD PASANDOLE LA POSICION
			        numMis--; // RESTAMOS EL CONTADO GENERAL DE MISIONES
			    }
					
	private int obtenerPosMis(String nombre,int nivel,Personaje objetivo) // METODO OBTENER POSICION DE LA MISION PASANDO EL NOMBRE, NIVEL Y OBJETIVO
			{
				int salida = -1;
				Zona zona = new Zona ();
				Item recompensa = new Consumible ();
				
				Mision aux = new Mision();
				
				for(int i = 0; i<numMis; i++)
				{
					if (misiones[i]!=null)
					aux = new Mision(nombre,nivel,objetivo,zona,recompensa,0);
				
					if(misiones[i] != null && misiones[i].esIgual(aux))
					{
						salida =i;
					}
				}
						
				return salida;
			}
		 
	public void mostrarMisiones() // METODO DE MOSTRAR LAS MISIONES
		{
			for(int i =0; i<numMis; i++)
			{
				if (misiones[i] !=null)
				misiones[i].visualizarBasico();
			}
		}
		
		// FIN DE LOS METODOS DE MISION ----------------------------------------------------------------------------------------------------------

}