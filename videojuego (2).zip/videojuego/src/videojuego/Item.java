package videojuego;

abstract class Item {
	
	// DECLARAMOS LAS VARIABLES
	
	protected String nombre ;
	protected int valor ;
	
	protected Habilidad acciones [] ;
	protected int numhabiItem;
	
	public Item() { // METODO CONSTRUCTOR POR DEFECTO
		
		nombre = " NINGUNO";
		valor = 0 ; 
		numhabiItem= 0 ; 
		acciones= new Habilidad [5];
		
	}
	
	// METODO SOBRECARGADO
	
	public Item (String nombre, int peso,String tipo ,int valor , int agravio , int armadura ,Habilidad acciones [] ) {
		this.numhabiItem = 0 ; 
		this.nombre = nombre;
		
		this.valor = valor ; 
		 
		this.acciones= new Habilidad [5];
		for (int i= 0 ; i < this.acciones.length; i++) {
			
			if(acciones [i]!=null && !this.tiene(acciones[i])) {

				this.acciones [numhabiItem] = acciones [i] ; 
				this.numhabiItem ++ ; 
			}
	
			
		}
	}
	// METODO DE COPIA 
	public Item (Item Item){
		
		this.nombre = Item.nombre;
		
		this.valor = Item.valor ; 
	
		this.numhabiItem = Item.numhabiItem ; 
		this.acciones= new Habilidad [5];
		for (int i= 0 ; i < this.acciones.length ; i++) {
			
			if(acciones [i]!=null && !this.tiene(acciones[i])) {
				
			this.acciones [i] = Item.acciones[i]; 
			
			}
		}
		
	}
	
	public void visualizar () { // VISUALIZAMOS NUESTROS ATRIBUTOS
		
		System.out.println("---------------------Item--------------------");
		System.out.println("Nombre: "+ nombre);
	
		System.out.println("Valor : "+ valor);
		
		System.out.println("Numero de acciones (habilidades) : "+ numhabiItem);
	
		
		System.out.println("------------------------------------------------");
		System.out.println();
	}
	
	public void visualizarHabItem () { // VISUALIZAMOS LAS HABILIDADES DEL ITEM
		

		for (int i = 0 ; i < this.acciones.length; i++) 
		{
			 if(this.acciones [i]!=null ) { 
				 
				System.out.println();
				System.out.println("Habilidad: " + (i+1));
				 acciones[i].visualizar();	
			 }
		}
	}
	
	public void visualizarBasico() {
		
		
		System.out.println("---------------------Item--------------------");
		System.out.println("Nombre: "+ nombre);
	
		System.out.println("Valor : "+ valor);
		
		System.out.println("Numero de acciones (habilidades) : "+ numhabiItem);
	
		
		System.out.println("------------------------------------------------");
		System.out.println();
		
	}


	 boolean tiene(Habilidad habilidad)
		{
			
			boolean salida = false;
			for(int i=0; i<this.numhabiItem; i++)
			{
				if(this.acciones[i]!=null && this.acciones[i].esIgual(habilidad))
					salida=true;
			}
			return salida;
		}
	 
	 public boolean esIgual(Item Item)
		{
			boolean salida = true;
		
			if(this.nombre.equals(Item.nombre) )
			{
				
				if(this.numhabiItem==Item.numhabiItem)
				{
					for(int i = 0; i<Item.numhabiItem;i++)
					{
						if(!this.tiene(Item.acciones[i]))
						{
							salida=false;
						}
					}
					
					}
				else 
					salida =false;
			}
			else
				salida =false;
				
			return salida;
		}

	
	 // GETTES Y SETTES
	 
	 public int getNumhabiItem() {
			return numhabiItem;
		}
		public void setNumhabiItem(int numhabiItem) {
			this.numhabiItem = numhabiItem;
		}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public int getValor() {
		return valor;
	}
	public void setValor(int valor) {
		this.valor = valor;
	}

	public Habilidad[] getAcciones() {
		return acciones;
	}
	public void setAcciones(Habilidad[] acciones) {
		this.acciones = acciones;
	}
	
}
	



